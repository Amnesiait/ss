# A.E.T.H.E.R. v7.4.0 "Infinity Loop" ♾️

> **Adaptive Evolution Trading & Hedging Execution Robot**  
> *Tier 1 Algorithmic Trading System for XAUUSD Scalping*

![Build Status](https://img.shields.io/github/actions/workflow/status/Gunasekar87/Scalping--Version-latest/aether_ci.yml?branch=main)
![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![License](https://img.shields.io/badge/License-MIT-green)

---

## 🧠 Project Overview

AETHER is not just a bot; it is an autonomous **Market Intelligence System**. Unlike traditional expert advisors that rely on static indicators, AETHER uses a multi-layered "Infinity Loop" architecture to predict, adapt, and survive any market condition.

It is designed with a **"Nil Loss" Philosophy**, prioritizing capital preservation through pre-emptive risk protocols ("Prophet Mode") and localized hedging ("God Mode").

## 🛡️ The Defense Hierarchy (The 5 Layers)

1.  **Layer 1: The Prophet (Predictive Vision)**
    *   Uses Order Book Imbalance & Macro Velocity to *predict* volatility events before they happen.
    *   Widens the recovery grid *pre-emptively* to capture news spikes safely.

2.  **Layer 2: Zone Recovery (Mathematical Shield)**
    *   State-of-the-art hedging algorithm that cost-averages out of adverse moves.
    *   Uses "Intelligent Volatility Scaling" to adapt distance based on market noise.

3.  **Layer 3: God Mode (Trend Lock)**
    *   Detects dangerous "Runaway Trends" where standard hedging fails.
    *   Instantly executes a **Perfect Hedge (Delta Neutral)** to freeze PnL until the market calms.

4.  **Layer 4: The Bad Bank (Debt Cleanup)**
    *   A background daemon that isolates "Toxic Locked Positions".
    *   Siphons small profits ("Tithes") from healthy trades to nibble away at the toxic debt.

5.  **Layer 5: Phoenix Protocol (Ejection Seat)**
    *   The ultimate fail-safe. If Equity Drawdown hits **25%**, it initiates a controlled emergency shutdown to save the remaining 75%.

### 📂 Enterprise Project Structure

```bash
AETHER/
├── config/                 # Configuration & Secrets
├── data/                   # Market Memory & Databases
├── logs/                   # Structured Logging
├── models/                 # AI Models (Prophet, Oracle)
├── src/                    # Source Code
│   ├── ai_core/            # Intelligence Layer (Oracle, PPO, Fusion)
│   ├── bridge/             # MT5 Connectivity
│   ├── core/               # Trade Authority & Constitution
│   ├── policy/             # Risk Governance
│   ├── infrastructure/     # Database & Async IO
│   ├── utils/              # Helpers & Telemetry
│   ├── market_data.py      # Market Data Stream
│   ├── position_manager.py # Trade Lifecycle
│   ├── risk_manager.py     # Risk Calculations
│   ├── trading_engine.py   # Main Execution Loop
│   └── run_bot.py          # Entry Point
├── tests/                  # QA Suite (Unit, Integration, Regression)
└── requirements.txt        # Dependencies
```

### ⚡ Quick Start

```powershell
# 1. Install Dependencies
pip install -r requirements.txt

# 2. Run in LIVE Mode
python run_bot.py --mode=LIVE
```

### Running Tests (QA)
This project adheres to professional QA standards included Regressions.
```bash
python -m pytest tests/ -v
```

## ⚠️ Disclaimer
Trading Forex and Commodities involves substantial risk. This software is provided for educational and research purposes only. The "Nil Loss" philosophy refers to the architectural goal of hedging, not a guarantee of financial profit.

---
*Architected by: AETHER Dev Team | Powered by Neural Intelligence*
