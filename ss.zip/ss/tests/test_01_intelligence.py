
import pytest
from unittest.mock import MagicMock
from src.ai_core.oracle import Oracle
from src.core.trade_authority import TradeAuthority
from src.policy.risk_governor import RiskGovernor, RiskLimits
from src.risk_manager import RiskManager

class TestIntelligenceLayer:
    
    def test_prophet_mode_prediction(self):
        """
        [HAPPY PATH] Oracle correctly predicts high volatility and boosts multiplier.
        """
        oracle = Oracle(MagicMock(), MagicMock())
        
        # 1. Mock internal methods to simulate High Volatility Signals
        oracle._get_order_book_imbalance = MagicMock(return_value=0.9) # Extreme Imbalance
        
        # 2. Run Prediction
        candles = [{'high': 10, 'low': 9, 'close': 10}] * 50 # Dummy candles
        macro_shock = [60.0, 0.0] # USD Spike 60bps
        
        vol_mult = oracle.predict_next_volatility("XAUUSD", candles, macro_context=macro_shock)
        
        print(f"\n[TEST] Prophet Volatility Multiplier: {vol_mult}")
        
        # 3. Assertions
        # Base (ATI) is low, but OBI (0.9 -> +0.45) + Macro (60 -> +0.6) should boost it.
        # Expectation: 1.0 + 0.45 + 0.6 = 2.05 approx
        assert vol_mult > 1.5, f"Prophet should predict high vol (Got {vol_mult})"
        assert vol_mult <= 5.0, "Prophet should cap at 5.0"

    def test_trade_authority_caps(self, mock_broker):
        """
        [UNHAPPY PATH] Trade Authority MUST veto trades exceeding caps.
        """
        authority = TradeAuthority()
        authority.current_global_cap = 10  # Set higher so global cap doesn't interfere with symbol cap test
        authority.current_hedge_cap = 3   # Symbol cap is 3
        
        # 1. Simulate Global Cap Full (use lower global cap first)
        authority2 = TradeAuthority()
        authority2.current_global_cap = 5
        authority2.current_hedge_cap = 10  # High hedge cap so symbol doesn't interfere
        
        mock_positions_global = [
            {'symbol': 'XAUUSD', 'type': 0, 'volume': 0.01},
            {'symbol': 'EURUSD', 'type': 0, 'volume': 0.01},
            {'symbol': 'GBPUSD', 'type': 0, 'volume': 0.01},
            {'symbol': 'USDJPY', 'type': 0, 'volume': 0.01},
            {'symbol': 'AUDUSD', 'type': 0, 'volume': 0.01},
        ] # 5 Open Positions = Global Cap Full
        
        mock_broker = MagicMock()
        mock_broker.get_positions.return_value = mock_positions_global
        
        approved, reason = authority2.check_constitution(mock_broker, "NZDUSD", 0.01, "OPEN")
        print(f"\n[TEST] Global Cap Check: {approved} ({reason})")
        assert approved is False, "Authority failed to enforce Global Cap"
        assert "Global Cap Reached" in reason
        
        # 2. Simulate Symbol Cap Full
        # 3 XAUUSD positions = Symbol Cap Full (current_hedge_cap=3)
        xau_positions = [
            {'symbol': 'XAUUSD', 'type': 0, 'volume': 0.01},
            {'symbol': 'XAUUSD', 'type': 0, 'volume': 0.01},
            {'symbol': 'XAUUSD', 'type': 0, 'volume': 0.01},
        ]
            
        mock_broker.get_positions.return_value = xau_positions
        
        approved, reason = authority.check_constitution(mock_broker, "XAUUSD", 0.01, "OPEN")
        print(f"\n[TEST] Symbol Cap Check: {approved} ({reason})")
        assert approved is False, "Authority failed to enforce Symbol Cap"
        assert "Symbol Cap Reached" in reason

    def test_macro_veto_logic(self):
        """
        [DEFENSE] RiskGovernor should VETO trades during Macro Shocks (Correlation Guardian).
        """
        limits = RiskLimits(0.15, 0.20, 2, False)
        governor = RiskGovernor(limits)
        
        # 1. Simulate USD Spike (Dollar Strength = Gold Weakness)
        metrics = {
            "macro_context": [60.0, 0.0], # USD_Vel = 60bps (Huge)
            "net_lot_exposure": 1.0, # We are LONG 1.0 Lot
            "balance": 10000,
            "equity": 10000,
            "total_exposure_pct": 0.05  # 5% exposure
        }
        
        veto, reason = governor.veto(metrics)
        print(f"\n[TEST] Macro Veto: {veto} ({reason})")
        
        # Main test: Governor should VETO Longs during USD Spike
        assert veto is True, "Governor should VETO Longs during USD Spike"
        assert "USDJPY SPIKE" in reason, f"Expected 'USDJPY SPIKE' in reason, got: {reason}"
        
        # 2. Test that lowering USD velocity removes the veto
        metrics["macro_context"] = [30.0, 0.0]  # Below 50 threshold
        veto, reason = governor.veto(metrics)
        assert veto is False, "Should allow trade when USD velocity is below threshold"

