
import pytest
from unittest.mock import MagicMock
import sys
import os

# Add src to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

@pytest.fixture
def mock_broker():
    broker = MagicMock()
    broker.get_account_info.return_value = {
        'balance': 10000.0,
        'equity': 10000.0,
        'margin': 0.0,
        'free_margin': 10000.0
    }
    broker.get_positions.return_value = []
    return broker

@pytest.fixture
def mock_market_data():
    md = MagicMock()
    # Standard Tick
    md.get_tick_data.return_value = {
        'bid': 2000.00,
        'ask': 2000.20,
        'time': 1234567890,
        'volume': 1.0,
        'flags': 6
    }
    # Standard History
    md.get_history.return_value = [
        {'time': 1000, 'open': 1999.0, 'high': 2001.0, 'low': 1998.0, 'close': 2000.0, 'tick_volume': 100, 'spread': 20}
        for _ in range(100)
    ]
    md.get_volatility_ratio.return_value = 1.0
    md.get_macro_context.return_value = [0.0, 0.0]
    return md

@pytest.fixture
def config():
    conf = MagicMock()
    conf.symbol = "XAUUSD"
    conf.timeframe = "M1"
    conf.min_equity = 5000.0
    # Add Risk Config mocks
    conf.max_hedges = 6
    conf.zone_pips = 25.0
    return conf

@pytest.fixture
def mock_position_manager():
    pm = MagicMock()
    pm.calculate_entry_lot.return_value = 0.1
    pm.open_position.return_value = True
    pm.close_position.return_value = True
    pm.get_open_positions.return_value = []
    pm.bucket_stats.return_value = {
        'total_profit': 0.0,
        'bucket_pnl': {},
        'win_count': 0,
        'loss_count': 0
    }
    pm.execute_perfect_hedge = MagicMock(return_value=False)
    return pm

@pytest.fixture
def mock_risk_manager():
    rm = MagicMock()
    rm.check_entry_allowed.return_value = True
    rm.update_exposure.return_value = True
    rm.can_hedge.return_value = True
    return rm
