
import unittest
import sys
import os

# Path correction
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from src.ai_core.kalman_trajectory import KalmanSniper

class TestKalmanSniper(unittest.TestCase):
    def setUp(self):
        self.sniper = KalmanSniper(gain=0.8)

    def test_smooth_convergence(self):
        """Test if Filter latches onto stable price."""
        # Feed 10 ticks of 2000.0
        for _ in range(10):
            t = self.sniper.update(2000.0)
            
        self.assertAlmostEqual(t.estimate, 2000.0, delta=0.5, msg="Sniper should converge to 2000.")
        self.assertLess(t.deviation, 1.0, "Deviation should be low on stable feed.")

    def test_breakout_lag(self):
        """Test if Filter reacts to breakout (Gain 0.8 should be fast)."""
        # 1. Stabilize at 2000
        self.sniper.update(2000.0)
        
        # 2. Jump to 2010
        t = self.sniper.update(2010.0)
        
        # With Gain 0.8, Estimate = 2000 + 0.8*(2010-2000) = 2008
        self.assertAlmostEqual(t.estimate, 2008.0, delta=0.5, msg="Gain 0.8 should capture 80% of move.")
        self.assertEqual(t.signal, "BUY", "Jump up should trigger BUY signal.")

    def test_reversal_sensitivity(self):
        """Test Reversal logic."""
        # 1. Up Trend (2000 -> 2010)
        self.sniper.update(2000.0)
        self.sniper.update(2010.0)
        
        # 2. Reversal (Dropping to 2005)
        # Prev Estimate ~2008. Measurement 2005. Err -3. 
        # New Est = 2008 + 0.8*(-3) = 2005.6
        t = self.sniper.update(2005.0)
        
        # Signal should likely be SELL or NEUTRAL depending on threshold
        # Assuming simple threshold logic in implementation
        pass

if __name__ == '__main__':
    unittest.main()
