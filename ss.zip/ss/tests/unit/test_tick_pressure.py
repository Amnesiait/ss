
import unittest
import sys
import os
import numpy as np

# Path correction
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from src.ai_core.tick_pressure import TickPressureAnalyzer

class TestTickPressure(unittest.TestCase):
    def setUp(self):
        self.analyzer = TickPressureAnalyzer()

    def test_sigma_calculation_basics(self):
        """Test Z-Score Math with known dataset."""
        # 1. Populate with stable data (Mean=100, StdDev=0)
        for _ in range(30):
            self.analyzer.add_tick({'bid': 100.0, 'time': 1000})
            
        # 2. Check Sigma for 100.0 (Should be 0 or handled as Stable)
        z, status = self.analyzer.calculate_sigma(100.0)
        self.assertEqual(status, "STABLE", "Zero variance should be STABLE.")

        # 3. Add Variance
        # [90, 110] -> Mean 100, StdDev ~10
        self.analyzer.ticks = [] # Reset
        self.analyzer.add_tick({'bid': 90.0, 'time': 1})
        self.analyzer.add_tick({'bid': 110.0, 'time': 2})
        # Need min 20 ticks logic?
        for _ in range(18): self.analyzer.add_tick({'bid': 100.0, 'time': 3})
        
        # Mean is roughly 100. StdDev roughly 3.
        # Test 115 (Should be ~5 Sigma)
        z, status = self.analyzer.calculate_sigma(115.0)
        self.assertGreater(abs(z), 2.0, "115 should be > 2 Sigma from 100.")

    def test_liquidity_vacuum(self):
        """Test Guard Spread Logic."""
        # Normal Spread
        tick_safe = {'bid': 2000.0, 'ask': 2000.30} # 30 cents
        is_crash, _ = self.analyzer.check_crash_status(tick_safe)
        self.assertFalse(is_crash, "30 cent spread is safe.")
        
        # Vacuum Spread
        tick_vacuum = {'bid': 2000.0, 'ask': 2000.60} # 60 cents
        is_crash, reason = self.analyzer.check_crash_status(tick_vacuum)
        self.assertTrue(is_crash, "60 cent spread should trigger Vacuum.")
        self.assertIn("LIQUIDITY_VACUUM", reason)

if __name__ == '__main__':
    unittest.main()
