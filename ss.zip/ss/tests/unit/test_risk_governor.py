
import unittest
import sys
import os

# Path correction
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from src.policy.risk_governor import RiskGovernor, RiskLimits

class TestRiskGovernor(unittest.TestCase):
    def setUp(self):
        # Use 0% Reserve for basic logic tests to make Raw = Shadow
        self.limits = RiskLimits(
            max_total_exposure_pct=0.15,
            max_drawdown_pct=0.20,
            position_limit_per_1k=2,
            news_lockout=True,
            capital_reserve_pct=0.0 
        )
        self.governor = RiskGovernor(self.limits)

    def test_safe_metrics(self):
        """Test a perfectly safe scenario."""
        metrics = {
            "balance": 10000.0, "equity": 10000.0, "margin": 100.0,
            "total_exposure_pct": 0.01, "account_drawdown_pct": 0.0, "news_now": False
        }
        veto, _ = self.governor.veto(metrics)
        self.assertFalse(veto, "Vault should NOT veto safe trade.")

    def test_exposure_limit_edge(self):
        """Test boundary of 15% exposure."""
        # 1. Exactly 15%
        metrics_boundary = {
            "balance": 10000.0, "equity": 10000.0, "margin": 1500.0,
            "total_exposure_pct": 0.15, "account_drawdown_pct": 0.0, "news_now": False
        }
        veto, reason = self.governor.veto(metrics_boundary)
        print(f"\n[DEBUG] Ex: 0.15 -> Veto: {veto}, Reason: {reason}")
        self.assertFalse(veto, f"Should ALLOW 15%. Got veto: {reason}")
        
        # 2. 15.01%
        metrics_over = {
            "balance": 10000.0, "equity": 10000.0, "margin": 1501.0,
            "total_exposure_pct": 0.1501, "account_drawdown_pct": 0.0, "news_now": False
        }
        veto, reason = self.governor.veto(metrics_over)
        print(f"[DEBUG] Ex: 0.1501 -> Veto: {veto}, Reason: {reason}")
        self.assertTrue(veto, "Should VETO 15.01%")

    def test_drawdown_hard_stop(self):
        """Test 20% Drawdown Hard Stop."""
        metrics_crash = {
            "balance": 10000.0, "equity": 7900.0, # 21% Drawdown
            "margin": 100.0, 
            "total_exposure_pct": 0.01,
            "account_drawdown_pct": 0.21, "news_now": False
        }
        veto, reason = self.governor.veto(metrics_crash)
        print(f"\n[DEBUG] DD: 0.21 -> Veto: {veto}, Reason: {reason}")
        self.assertTrue(veto, "Should VETO 21% Drawdown")

    def test_capital_reserve_check(self):
        """Test Reserve Requirement (Safety Buffer)."""
        # If Reserve is 85%, we can only use 15%.
        # This is redundant with exposure limit but checks the logic path.
        pass # Implementation in RiskGovernor might rely on exposure_pct mostly.

if __name__ == '__main__':
    unittest.main()
