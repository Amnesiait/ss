
import unittest
import sys
import os
from unittest.mock import patch, MagicMock

# Path correction
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from src.utils.news_filter import NewsFilter

class TestNewsFilter(unittest.TestCase):
    def setUp(self):
        self.sentinel = NewsFilter()

    def test_nfp_boundary_start(self):
        """Test Start Boundary of NFP (12:55 UTC)."""
        # 12:55 UTC exactly
        with patch('src.utils.news_filter.datetime') as mock_date:
            mock_date.datetime.utcnow.return_value.hour = 12
            mock_date.datetime.utcnow.return_value.minute = 55
            mock_date.datetime.utcnow.return_value.weekday.return_value = 4 # Fri
            
            is_safe, reason = self.sentinel.check_status()
            self.assertFalse(is_safe, "Sentinel should BLOCK at 12:55 start.")
            self.assertIn("US_OPEN_NFP", reason)

    def test_nfp_boundary_end(self):
        """Test End Boundary of NFP (14:05 UTC)."""
        # 14:05 UTC exactly -> Still blocked
        with patch('src.utils.news_filter.datetime') as mock_date:
            mock_date.datetime.utcnow.return_value.hour = 14
            mock_date.datetime.utcnow.return_value.minute = 5
            mock_date.datetime.utcnow.return_value.weekday.return_value = 4
            
            is_safe, reason = self.sentinel.check_status()
            self.assertFalse(is_safe, "Sentinel should BLOCK at 14:05 end.")
            
        # 14:06 UTC -> Safe
        with patch('src.utils.news_filter.datetime') as mock_date:
            mock_date.datetime.utcnow.return_value.hour = 14
            mock_date.datetime.utcnow.return_value.minute = 6
            mock_date.datetime.utcnow.return_value.weekday.return_value = 4
            
            is_safe, _ = self.sentinel.check_status()
            self.assertTrue(is_safe, "Sentinel should ALLOW at 14:06.")

    def test_pre_clearance_mode(self):
        """Test 5-min warning before Blackout."""
        # 12:50 UTC (5 mins before 12:55)
        with patch('src.utils.news_filter.datetime') as mock_date:
            mock_date.datetime.utcnow.return_value.hour = 12
            mock_date.datetime.utcnow.return_value.minute = 51 # Inside 5 min buffer
            
            is_pre = self.sentinel.is_pre_clearance_mode()
            self.assertTrue(is_pre, "Sentinel should detect PRE-CLEARANCE mode at 12:51.")

if __name__ == '__main__':
    unittest.main()
