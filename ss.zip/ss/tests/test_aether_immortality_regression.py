import pytest
import asyncio
from unittest.mock import MagicMock, patch
from src.policy.risk_governor import RiskGovernor, RiskLimits
from src.trading_engine import TradingEngine
from src.config.settings import RISK

@pytest.mark.asyncio
class TestImmortalityRegression:
    
    def setup_method(self):
        # Verify the global RISK setting is as expected for the test context
        # although we will inject custom limits for the governor test.
        self.limits = RiskLimits(
            max_total_exposure_pct=0.15,
            max_drawdown_pct=0.20,
            position_limit_per_1k=2,
            news_lockout=True,
            capital_reserve_pct=0.6  # 60% Reserve
        )
        self.governor = RiskGovernor(self.limits)

    def test_shadow_balance_calculation_60_40(self):
        """
        [REGRESSION] Verify 60/40 Shadow Balance logic.
        With $10,000 balance and 60% reserve, effective balance must be $4,000.
        """
        metrics = {
            "balance": 10000.0,
            "equity": 10000.0,
            "total_exposure_pct": 0.0,
            "account_drawdown_pct": 0.0
        }
        
        # We need to trace internal calculations in veto
        # Since veto doesn't return them, we check the 'shadow_exposure_pct' implication
        # If we use $1500 margin:
        # Real exposure = 15%
        # Shadow exposure = 1500 / 4000 = 37.5%
        
        metrics_high_shadow = {
            "balance": 10000.0,
            "equity": 10000.0,
            "margin": 1500.0,
            "total_exposure_pct": 0.15, # 15% of total
            "account_drawdown_pct": 0.0
        }
        
        veto, reason = self.governor.veto(metrics_high_shadow)
        assert veto is True
        assert "veto:exposure" in reason
        # Explicit check: 15% real exposure on a 60% reserve account is 37.5% shadow exposure.
        # Max exposure limit is 15%. 37.5% > 15% -> VETO.

    async def test_solvency_restoration_logic(self):
        """
        [REGRESSION] Verify Phoenix Protocol uses Bad Bank offloading instead of Ejection Seat.
        """
        mock_broker = MagicMock()
        mock_market_data = MagicMock()
        mock_pos_manager = MagicMock()
        mock_risk_manager = MagicMock()
        mock_config = MagicMock()
        mock_config.symbol = "XAUUSD"
        
        # Setup TradingEngine
        engine = TradingEngine(mock_config, mock_broker, mock_market_data, mock_pos_manager, mock_risk_manager)
        
        # Mock Drawdown > 25%
        mock_broker.get_account_info.return_value = {
            'balance': 10000.0,
            'equity': 5000.0  # 50% Drawdown (> 35% Trigger)
        }
        
        # Mock tick data for Valkyrie
        mock_market_data.get_tick_data.return_value = {'ask': 2000.5, 'bid': 2000.0}
        
        # Mock bucket stats
        engine.position_manager.bucket_stats.keys.return_value = ['toxic_bucket_1']
        
        # Mock successful hedge and offload
        # Use AsyncMock for awaited methods
        from unittest.mock import AsyncMock
        engine.position_manager.execute_perfect_hedge = AsyncMock(return_value=True)
        # offload_bucket_to_bad_bank is NOT async in the real code (I checked earlier)
        # Wait, let me check again.
        engine.position_manager.offload_bucket_to_bad_bank = MagicMock(return_value=True)
        
        # We also need to mock _governor.reset_emergency_mode
        engine._governor = MagicMock()
        # Fix for TypeError: mock limits.capital_reserve_pct must be a float
        engine._governor.limits.capital_reserve_pct = 0.60
        with patch('src.trading_engine.ui_logger') as mock_ui:
            # RUN SAFETY CHECK
            await engine._check_global_safety()
            
            # VERIFY:
            # 1. Perfect Hedge was called
            engine.position_manager.execute_perfect_hedge.assert_called()
            # 2. Bad Bank Offload was called (THIS IS THE IMMORTALITY FIX)
            engine.position_manager.offload_bucket_to_bad_bank.assert_called_with('toxic_bucket_1')
            # 3. Ejection Seat (Close Positions) was NOT called
            mock_broker.close_positions.assert_not_called()
            # 4. Safety Lock is NOT set (Resuming trading)
            assert getattr(engine, '_safety_lock', False) is False

if __name__ == "__main__":
    pytest.main([__file__])
