"""
AETHER Performance Analyzer
Analyzes decision logs to evaluate AI prediction accuracy and Breakout Intelligence.
"""

import os
import json
import glob
from datetime import datetime
import statistics

def load_logs(log_dir):
    files = glob.glob(os.path.join(log_dir, "*.jsonl"))
    files.sort(key=os.path.getmtime, reverse=True)
    
    if not files:
        print("No log files found.")
        return []
    
    # Analyze latest file by default, or all? Let's do latest for "Current Session"
    target_file = files[0]
    print(f"Analyzing Log File: {os.path.basename(target_file)}")
    
    data = []
    with open(target_file, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                if line.strip():
                    data.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return data

def analyze_predictions(data):
    total_decisions = 0
    actions = {"BUY": 0, "SELL": 0, "HOLD": 0}
    sr_blocks = 0
    breakouts_allowed = 0
    
    confidences = []
    
    for entry in data:
        decision = entry.get('decision', {})
        action = decision.get('action')
        conf = decision.get('confidence', 0)
        
        if action:
            total_decisions += 1
            actions[action] = actions.get(action, 0) + 1
            confidences.append(conf)
            
        # Check for SR Logic in reasoning
        reasoning = decision.get('reasoning', '')
        if "BLOCKED" in reasoning or "Buying into Resistance" in reasoning:
            sr_blocks += 1
        if "BREAKOUT PREDICTED" in reasoning:
            breakouts_allowed += 1

    print("\n=== AI PERFORMANCE REPORT ===")
    print(f"Total Decisions: {total_decisions}")
    print(f"Action Distribution: {actions}")
    
    if confidences:
        avg_conf = statistics.mean(confidences)
        print(f"Average Confidence: {avg_conf:.1%}")
    else:
        print("Average Confidence: N/A")

    print("\n=== INTELLIGENCE METRICS ===")
    print(f"S/R Protection Blocks: {sr_blocks}")
    print(f"Smart Breakouts Allowed: {breakouts_allowed}")
    
    if sr_blocks + breakouts_allowed > 0:
        breakout_ratio = breakouts_allowed / (sr_blocks + breakouts_allowed)
        print(f"Breakout Aggressiveness: {breakout_ratio:.1%}")
    else:
        print("Breakout Aggressiveness: 0.0% (No S/R events detected)")

if __name__ == "__main__":
    log_dir = os.path.join(os.getcwd(), "logs", "decisions")
    logs = load_logs(log_dir)
    if logs:
        analyze_predictions(logs)
