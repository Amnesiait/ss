"""
Trade Authority - The "Supreme Court" of the AETHER System.
Part of the AETHER Intelligence Stack (Layer 0: Constitution).

This module acts as the Central Gatekeeper. It enforces immutable laws (The Constitution)
that NO other module (including God Mode) can bypass.

Responsibility:
1. Prevent "Unlimited Trades" by enforcing Global & Symbol Caps.
2. Adapt limits based on Market Volatility (Adaptive Constitution).
3. Veto any trade that violates risk parameters.

Author: AETHER Development Team
License: MIT
Version: 1.0.0
"""

import logging
from typing import Dict, Tuple, Optional
from src.utils.data_normalization import normalize_positions

logger = logging.getLogger("TradeAuthority")

class TradeAuthority:
    """
    The Supreme Court.
    All trade requests must be approved here before execution.
    """
    
    def __init__(self, config=None):
        from src.constants import RiskLimits as GlobalRiskLimits
        
        # --- THE CONSTITUTION (Immutable Laws) ---
        # NOW LINKED TO CENTRALIZED CONSTANTS (No more hardcoded values)
        self.max_global_positions_base = GlobalRiskLimits.MAX_GLOBAL_POSITIONS # Should be 5
        self.max_hedges_per_symbol = GlobalRiskLimits.MAX_HEDGES_PER_SYMBOL # Should be 6
        
        # Buffer = Total (10) - Base (5) = 5
        self.god_mode_buffer = GlobalRiskLimits.MAX_GLOBAL_POSITIONS_WITH_GOD_MODE - GlobalRiskLimits.MAX_GLOBAL_POSITIONS
        
        # Current State
        self.current_global_cap = self.max_global_positions_base
        self.current_hedge_cap = self.max_hedges_per_symbol
        self.volatility_state = "NORMAL"
        
        logger.info(f"[SUPREME COURT] Trade Authority Initialized. Laws: Base={self.max_global_positions_base}, GodBuffer={self.god_mode_buffer} (Total={self.max_global_positions_base + self.god_mode_buffer}).")

    def update_constitution(self, atr_value: float, equity: float):
        """
        Adaptive Adjustment of Laws based on Market Conditions.
        Called periodically (e.g., every minute).
        
        Args:
            atr_value: Current market volatility.
            equity: Account equity.
        """
        # 1. Volatility Adjustment
        # If ATR is high (> 2.0 on Gold), we clamp down hard (max 4).
        # If ATR is low (< 1.0 on Gold), we allow slight expansion (max 8).
        
        if atr_value > 2.0: 
            self.current_hedge_cap = 4  # High volatility: reduce risk
            self.volatility_state = "HIGH_VOLATILITY (Defense Mode)"
        elif atr_value < 1.0:
            self.current_hedge_cap = 8  # Low volatility: allow expansion to 8
            self.volatility_state = "LOW_VOLATILITY (Expansion Mode)"
        else:
            self.current_hedge_cap = 6  # Normal: limit to 6
            self.volatility_state = "NORMAL"
            
        # Global Cap logic: sufficient headroom to let per-symbol limits drive safety
        self.current_global_cap = self.max_global_positions_base
            
        # 2. Equity Adjustment (Scale up for large accounts, but cap at 15)
        # We REMOVED the "20" limit that caused the issue. Hard Cap is now 15.
        if equity > 50000:
            self.current_global_cap = min(self.current_global_cap + 2, 15)

    def check_constitution(self, broker, symbol: str, volume: float, action: str, is_god_mode: bool = False) -> Tuple[bool, str]:
        """
        The Judgment.
        Decides if a trade request is Constitutional.
        
        Args:
            broker: Broker instance to fetch current state.
            symbol: Symbol to trade.
            volume: Requested volume.
            action: "OPEN" or "CLOSE" (Closes are always allowed).
            is_god_mode: If True, allows emergency buffer beyond normal caps.
            
        Returns:
            (Approved: bool, Reason: str)
        """
        # AMENDMENT 0: Closing trades is always Constitutional
        if action == "CLOSE" or action == "CLOSE_ALL":
            return True, "Closing trades is always allowed"

        # Fetch Current State
        all_positions = broker.get_positions()
        if all_positions is None:
            return False, "VETOED: Cannot read current positions (System Blind)"
            
        # Optimize: Normalize once using utility
        all_positions = normalize_positions(all_positions)
        total_positions = len(all_positions)
        symbol_positions = len([p for p in all_positions if p.get('symbol') == symbol])
        
        # AMENDMENT 1: Global Cap (Account-Wide Safety)
        effective_global_cap = self.current_global_cap + (self.god_mode_buffer if is_god_mode else 0)
        
        # AMENDMENT 2: Symbol Cap (Symbol-Specific Adaptive Safety)
        effective_symbol_cap = self.current_hedge_cap + (self.god_mode_buffer if is_god_mode else 0)
        
        # UNIFIED LOGIC: Check both and report clearly
        if total_positions >= effective_global_cap:
            msg = f"VETOED: Account-Wide Cap Reached ({total_positions}/{effective_global_cap}). State: {self.volatility_state}"
            self._log_veto("global", msg)
            return False, msg
            
        if symbol_positions >= effective_symbol_cap:
            mode_label = "[GOD MODE ACTIVE]" if is_god_mode else ""
            # Unified feedback: Show Symbol AND Global in the veto
            msg = f"VETOED: Symbol Cap Reached for {symbol} ({symbol_positions}/{effective_symbol_cap}) | Account: {total_positions}/{effective_global_cap} {mode_label}. State: {self.volatility_state}"
            self._log_veto(f"symbol_{symbol}", msg)
            return False, msg
            
        # AMENDMENT 3: Volume/Exposure Check
        # Prevent absurdly large trades (e.g. fat finger or bug)
        # Max single trade size = 1.0 lot (Realistic Retail Safety Cap)
        # 5.0 was institutional size. 1.0 is standard max for automated scalpers.
        if volume > 1.0:
             msg = f"VETOED: Excessive Volume ({volume} lots > 1.0 allowed for Safety)"
             logger.warning(f"[SUPREME COURT] {msg}")
             return False, msg

        # AMENDMENT 4: Margin Validation (Bug #8 Fix)
        # Prevent trades that use too much free margin
        try:
            account_info = broker.get_account_info()
            if account_info:
                free_margin = account_info.get('margin_free', 0.0)
                current_price = broker.get_current_price(symbol)
                
                # Calculate estimated margin (Safety Check)
                # Formula: (Volume * ContractSize * Price) / Leverage
                # We assume 500:1 leverage for safety if unknown (standard)
                leverage = account_info.get('leverage', 500)
                contract_size = 100 if "XAU" in symbol or "GOLD" in symbol else 100000
                
                req_margin = (volume * contract_size * current_price) / leverage
                
                # Rule: Single trade cannot use > 50% of Free Margin
                if req_margin > (free_margin * 0.5):
                     msg = f"VETOED: Margin Danger. Req ${req_margin:.2f} > 50% Free Margin (${free_margin:.2f})"
                     logger.warning(f"[SUPREME COURT] {msg}")
                     return False, msg
        except Exception as e:
            logger.error(f"[SUPREME COURT] Margin Check Error: {e}")
            # Fail safe: allow if check fails but log error? Or block? 
            # Better to block in critical systems, but here we might soft-fail.
            pass

        # [PHASE 6] Throttle approvals to prevent terminal spam
        last_log = getattr(self, '_last_approval_log', {}).get(symbol, 0)
        import time
        if time.time() - last_log > 300: # 5 min throttle
            label = "✅ GOD MODE APPROVED" if is_god_mode else "✅ APPROVED"
            
            # [SIMPLIFICATION] If user is trading only one symbol (or just XAUUSD),
            # showing two counts (Symbol vs Global) is redundant and confusing.
            # We check if this symbol accounts for all global positions.
            is_single_pair_mode = (symbol_positions == total_positions)
            
            if is_single_pair_mode:
                 # Single Condition: Just show the effective limit for this symbol
                 logger.debug(f"[SUPREME COURT] {label}: {symbol} ({symbol_positions}/{effective_symbol_cap})")
            else:
                 # Multi-Pair: Show both to explain why one might be capped while other isn't
                 logger.debug(f"[SUPREME COURT] {label}: {symbol} ({symbol_positions}/{effective_symbol_cap}) | Account: ({total_positions}/{effective_global_cap})")

            if not hasattr(self, '_last_approval_log'): self._last_approval_log = {}
            self._last_approval_log[symbol] = time.time()

        return True, "APPROVED"

    def _log_veto(self, key: str, msg: str):
        """Helper to throttle veto logging."""
        import time
        current_time = time.time()
        if not hasattr(self, '_last_veto_log'): self._last_veto_log = {}
        last_time = self._last_veto_log.get(key, 0)
        
        if current_time - last_time > 300: # 5 min throttle
            logger.info(f"[SUPREME COURT] {msg}")
            self._last_veto_log[key] = current_time
