"""
Risk Governor - Intelligent account protection with profit-seeking emergency exit.

This module enforces smart limits on account exposure and provides
intelligent emergency exit logic that aims to close trades in PROFIT.
"""

import logging
from dataclasses import dataclass
from typing import Tuple, Optional, Dict, List, Any
import time

logger = logging.getLogger("RiskGovernor")


@dataclass
class RiskLimits:
    """Configuration for risk limits."""
    max_total_exposure_pct: float  # Maximum total margin usage % (e.g., 0.15 = 15%)
    max_drawdown_pct: float  # Maximum account drawdown % (e.g., 0.20 = 20%)
    position_limit_per_1k: int  # Positions allowed per $1000 balance (e.g., 2 = 2 positions per $1k)
    news_lockout: bool  # Block trading during news events
    capital_reserve_pct: float = 0.6  # [TREASURY] Default 60% Frozen Reserve


class RiskGovernor:
    """
    Enforces intelligent risk limits to protect account.
    
    Key Features:
    - Emergency exit aims to close trades in PROFIT
    - Dynamic position limits based on account balance
    - Intelligent recovery mode before shutdown
    - Shadow Accounting for "Ghost" Risk (Pre-Broker Updates)
    """
    
    def __init__(self, limits: RiskLimits):
        self.limits = limits
        self.valkyrie_active: bool = False  # Valkyrie Protocol (The Freeze)
        self.emergency_shutdown: bool = False  # Full shutdown (last resort)
        self.shutdown_reason: str = ""
        self.recovery_attempts: int = 0
        self.max_recovery_attempts: int = 3
        
        # Shadow Accounting
        self.shadow_exposure: float = 0.0
        
        from src.constants import RiskLimits as GlobalRiskLimits
        logger.info(f"RiskGovernor initialized: Max Exposure={limits.max_total_exposure_pct:.1%}, "
                   f"Max Drawdown={limits.max_drawdown_pct:.1%} (Valkyrie Trigger), "
                   f"Fixed Strategy Limit={GlobalRiskLimits.MAX_GLOBAL_POSITIONS} positions")
    
    @staticmethod
    def calculate_dynamic_reserve(balance: float) -> float:
        """
        Calculate dynamic capital reserve percentage based on account size.
        
        Institutional approach: Micro accounts need more active capital for viability,
        large accounts need more reserves for stability.
        
        Args:
            balance: Current account balance
            
        Returns:
            Reserve percentage (0.0-1.0)
        """
        if balance < 2000:
            return 0.50  # 50% reserve (50% active) for micro accounts
        elif balance < 5000:
            return 0.55  # 55% reserve (45% active)
        elif balance < 10000:
            return 0.60  # 60% reserve (40% active)
        else:
            return 0.65  # 65% reserve (35% active) for professional accounts

    
    def set_daily_baseline(self, balance: float) -> None:
        """Sets the daily starting balance for drawdown calculations (Not fully used yet)."""
        pass 

    def vote(self, metrics: Dict[str, Any], intent: str = "OPEN") -> Tuple[bool, str]:
        """Legacy method alias for veto."""
        return self.veto(metrics, intent)

    def veto(self, metrics: Dict[str, Any], intent: str = "OPEN") -> Tuple[bool, str]:
        """
        Check if trading should be blocked based on risk metrics.
        
        [SHADOW ACCOUNTING EXPLAINED]
        To protect the principal capital, this method calculates 'Shadow Metrics'
        based only on the 'Trading Ratio' (1.0 - Capital Reserve).
        - If Reserve = 85%, we trade as if the account is 15% the size.
        - A 15% Max Exposure limit applies to this 15% slice.
        - This effectively caps Real Exposure at 2.25% (0.15 * 0.15).
        
        Args:
            metrics: Dictionary containing:
                - total_exposure_pct (float): Current margin usage / Balance
                - total_positions (int): Number of open positions
                - account_drawdown_pct (float): Current drawdown
                - news_now (bool): News event flag
                - balance (float): Account Balance
                - equity (float): Account Equity
                - macro_context (List[float]): [USD_Vel, Risk_Vel]
                - net_lot_exposure (float): Net exposure in lots
                
        Returns:
            Tuple of (should_veto: bool, reason: str)
        """
        # [THE TREASURY] Shadow Balance Logic
        # We trade with only a portion of the funds. The rest is a "Doomsday Reserve".
        real_balance = float(metrics.get("balance", 10000.0))
        real_equity = float(metrics.get("equity", real_balance))  # Default to balance if equity missing
        
        # [INSTITUTIONAL] Calculate dynamic reserve based on account size
        effective_reserve_pct = self.calculate_dynamic_reserve(real_balance)
        
        # Calculate Shadow (Effective) Capital
        trading_ratio = 1.0 - effective_reserve_pct
        effective_balance = real_balance * trading_ratio
        
        # Effective Equity = Real Equity - Reserved Portion
        # Reserved Portion = Real Balance * Dynamic Reserve PCT
        reserved_cash = real_balance * effective_reserve_pct
        effective_equity = real_equity - reserved_cash
        
        # Recalculate Drawdown based on Shadow Balance
        # Drawdown = (Balance - Equity) / Balance
        # Shadow Drawdown = (Eff Balance - Eff Equity) / Eff Balance
        if effective_balance > 0:
            shadow_drawdown_pct = (effective_balance - effective_equity) / effective_balance
        else:
            shadow_drawdown_pct = 0.0

        # Check if full shutdown is active
        if self.emergency_shutdown:
            return True, f"EMERGENCY_SHUTDOWN: {self.shutdown_reason}"
        
        # Check 1: Total Exposure Limit
        # Recalculate Exposure based on Shadow Balance
        # Exposure = Used Margin / Effective Balance
        # Use passed 'total_exposure_pct' but scale it.
        # Passed Pct = Margin / RealBalance.
        # We want Margin / EffBalance. 
        # EffBalance = RealBalance * Ratio.
        # So NewPct = (Margin / RealBalance) / Ratio = PassedPct / Ratio.
        
        raw_exposure_pct = float(metrics.get("total_exposure_pct", 0.0))
        # Add local shadow exposure (transient)
        raw_exposure_pct += self.shadow_exposure
        
        # Shadow exposure IS the real exposure (no artificial scaling)
        # We scale the LIMIT based on trading ratio, not the measurement
        shadow_exposure_pct = raw_exposure_pct
        effective_limit = self.limits.max_total_exposure_pct * trading_ratio
        
        if shadow_exposure_pct > effective_limit:
            # [THROTTLING] Log first time as WARNING, then DEBUG to prevent spam
            last_log = getattr(self, '_last_shadow_exposure_log', 0)
            if time.time() - last_log > 60:  # Log once per minute
                logger.warning(f"[RISK_GOVERNOR] Exposure limit breached: {shadow_exposure_pct:.2%} > {effective_limit:.2%} (limit scaled by {trading_ratio:.0%} trading ratio)")
                self._last_shadow_exposure_log = time.time()
            else:
                logger.debug(f"[RISK_GOVERNOR] Exposure still breached: {shadow_exposure_pct:.2%} > {effective_limit:.2%}")
            return True, "veto:exposure_limit"
        
        # Check 2: Dynamic Position Count Limit
        total_positions = int(metrics.get("total_positions", 0))
        # Use Effective Balance for position limits
        max_positions = self._calculate_dynamic_position_limit(effective_balance)
        
        if total_positions >= max_positions:
            # [THROTTLING] Limit log frequency to once per minute per state
            last_log = getattr(self, '_last_pos_limit_log', 0)
            if time.time() - last_log > 60:
                logger.info(f"[RISK_GOVERNOR] Dynamic position limit reached: {total_positions}/{max_positions} (Balance: ${effective_balance:.0f})")
                self._last_pos_limit_log = time.time()
            return True, f"veto:max_positions_{max_positions}"
        
        # Check 3: Account Drawdown Limit (CRITICAL - triggers intelligent exit)
        # Use Shadow Drawdown calculated above
        if shadow_drawdown_pct >= 0.15:  # [VALKYRIE] Trigger at 15% of TRADING CAPITAL (not Total)
            # Activate Valkyrie Protocol - FREEZE THE ACCOUNT
            if not self.valkyrie_active:
                real_dd = max(0.0, (real_balance - real_equity) / real_balance) if real_balance > 0 else 0.0
                self._activate_valkyrie_protocol(
                    f"Shadow Drawdown limit breached: {shadow_drawdown_pct:.2%} >= 15% (Real DD: {real_dd:.2%})",
                    metrics
                )
            
            # [EXEMPTION] Allow Recovery trades (Hedging) to bypass Valkyrie block.
            # We want the bot to hedge even if DD is high, to lock the risk.
            if intent == "RECOVERY":
                # [THROTTLING] Prevent log spam during ongoing recovery
                last_bypass_log = getattr(self, '_last_bypass_log', 0)
                if time.time() - last_bypass_log > 60:
                     logger.info(f"[RISK_GOVERNOR] ✅ Recovery Intent Bypass for Valkyrie Active (DD: {shadow_drawdown_pct:.2%})")
                     self._last_bypass_log = time.time()
                return False, ""
                
            return True, "veto:valkyrie_active"
        
        # Check 4: News Lockout
        if self.limits.news_lockout and metrics.get("news_now", False):
            logger.info("[RISK_GOVERNOR] News event detected - trading locked")
            return True, "veto:news_event"

        # [CORRELATION GUARDIAN] Highest Intelligence Macro Check
        # Check if correlated assets (USDJPY, US500) imply imminent danger for Gold.
        macro_context = metrics.get("macro_context", [0.0, 0.0])  # [USD_Vel, Risk_Vel]
        usdjpy_vel = float(macro_context[0])
        risk_vel = float(macro_context[1])

        # 1. USD SPIKE CHECK (Dollar Strength = Gold Weakness)
        # 50 bps move in 1 min is a massive impulse (0.5%)
        DOLLAR_SPIKE_THRESHOLD = 50.0 
        if usdjpy_vel > DOLLAR_SPIKE_THRESHOLD:
            # Check if we are long Gold
            current_net = float(metrics.get('net_lot_exposure', 0.0))  # Assumes passed by TradingEngine
            if current_net > 0:
                msg = f"MACRO_VETO: USDJPY SPIKE ({usdjpy_vel:.1f}bps). DOLLAR STRENGTH = GOLD CRASH."
                # If HIGH exposure, freeze.
                if shadow_exposure_pct > 0.10:  # >10% exposure
                     self._activate_valkyrie_protocol(f"PRE-EMPTIVE MACRO SHOCK: USDJPY {usdjpy_vel:.1f}", metrics)
                return True, msg
        
        # 2. MARKETS CRASH CHECK (Risk Off = Liquidity Crunch)
        # US500 dumping hard often drags everything down (Margin Calls)
        MARKET_CRASH_THRESHOLD = -50.0
        if risk_vel < MARKET_CRASH_THRESHOLD:
             if shadow_exposure_pct > 0.05:
                  # Pre-emptive freeze logic
                  self._activate_valkyrie_protocol(f"PRE-EMPTIVE MACRO SHOCK: US500 CRASH {risk_vel:.1f}", metrics)
             return True, f"MACRO_VETO: US500 CRASH ({risk_vel:.1f}bps). RISK OFF."
        
        # All checks passed
        return False, ""
    
    def _calculate_dynamic_position_limit(self, balance: float) -> int:
        """
        Calculate dynamic position limit based on account balance.
        
        Args:
            balance: Current account balance
            
        Returns:
            Maximum allowed positions
        """
        from src.constants import RiskLimits as GlobalRiskLimits
        
        # [STRATEGY CONSTANCY] 
        # User Logic: "Only lot sizes matter based on account balance"
        # We allow the full Strategy Count (5) regardless of balance size.
        # Small accounts are protected by Lot Sizing (0.01 min) and Margin Checks, not by artificial count caps.
        return GlobalRiskLimits.MAX_GLOBAL_POSITIONS
    
    def _activate_valkyrie_protocol(self, reason: str, metrics: Dict[str, Any]) -> None:
        """
        Activate Valkyrie Protocol - The "Perfect Hedge" Freeze.
        Instead of closing trades (realizing loss), we open an opposing trade to net 0 delta.
        
        Args:
            reason: Reason for activation
            metrics: Current metrics
        """
        if not self.valkyrie_active:
            self.valkyrie_active = True
            self.shutdown_reason = reason
            logger.critical(f"[RISK_GOVERNOR] ❄️ VALKYRIE PROTOCOL ACTIVATED: {reason}")
            logger.critical("[RISK_GOVERNOR] Requesting PERFECT HEDGE to freeze account state.")
            # Note: The actual hedge execution happens in PositionManager/TradingEngine
            # when they see this flag.
    
    def register_shadow_risk(self, estimated_margin: float, balance: float) -> None:
        """
        Temporarily adds 'Shadow Risk' to calculations to prevent
        double-entry before broker API reflects the new position.
        """
        if balance > 0:
            exposure_impact = estimated_margin / balance
            self.shadow_exposure += exposure_impact
            logger.debug(f"[SHADOW] Added {exposure_impact:.2%} shadow exposure. Total: {self.shadow_exposure:.2%}")

    def resolve_shadow_risk(self) -> None:
        """Clears shadow risk (call this after broker API updates)."""
        self.shadow_exposure = 0.0

    def _create_intelligent_exit_strategy(self, positions: List[Dict]) -> Dict[str, Any]:
        """
        Create intelligent exit strategy to close trades in profit.
        
        Strategy:
        1. Close all profitable positions immediately
        2. For losing positions, wait for recovery or use smart hedging
        3. Set tight trailing stops on all positions
        4. If recovery fails after N attempts, force close at best available price
        
        Args:
            positions: List of position dictionaries
            
        Returns:
            Exit strategy dictionary
        """
        profitable = []
        losing = []
        total_pnl = 0.0
        
        for pos in positions:
            pnl = float(pos.get('profit', 0.0))
            total_pnl += pnl
            
            if pnl > 0:
                profitable.append(pos)
            else:
                losing.append(pos)
        
        strategy = {
            'total_positions': len(positions),
            'profitable_count': len(profitable),
            'losing_count': len(losing),
            'total_pnl': total_pnl,
            'profitable_positions': profitable,
            'losing_positions': losing,
            'actions': []
        }
        
        # Action 1: Close profitable positions immediately
        if profitable:
            strategy['actions'].append({
                'action': 'CLOSE_PROFITABLE',
                'count': len(profitable),
                'expected_profit': sum(float(p.get('profit', 0)) for p in profitable),
                'priority': 1
            })
        
        # Action 2: For losing positions, set tight trailing stops
        if losing:
            strategy['actions'].append({
                'action': 'SET_TIGHT_STOPS',
                'count': len(losing),
                'stop_distance_pips': 5,  # Very tight stop
                'priority': 2
            })
        
        # Action 3: Wait for recovery (give positions a chance)
        if losing:
            strategy['actions'].append({
                'action': 'WAIT_FOR_RECOVERY',
                'count': len(losing),
                'max_wait_minutes': 5,  # Wait max 5 minutes
                'priority': 3
            })
        
        # Action 4: If recovery fails, force close at best price
        if losing:
            strategy['actions'].append({
                'action': 'FORCE_CLOSE_IF_NO_RECOVERY',
                'count': len(losing),
                'trigger': 'after_recovery_attempts',
                'priority': 4
            })
        
        # Summary
        if profitable and not losing:
            summary = f"✅ All {len(profitable)} positions profitable - Close immediately"
        elif profitable and losing:
            summary = f"⚠️ Mixed: {len(profitable)} profitable (close now), {len(losing)} losing (wait for recovery)"
        else:
            summary = f"❌ All {len(losing)} positions losing - Wait for recovery, then force close"
        
        strategy['summary'] = summary
        
        return strategy
    
    def get_exit_strategy(self) -> Optional[Dict[str, Any]]:
        """
        Get the current exit strategy if emergency mode is active.
        
        Returns:
            Exit strategy dict or None
        """
        if self.emergency_shutdown and hasattr(self, 'exit_strategy'):
            return getattr(self, 'exit_strategy', None)
        return None
    
    def should_close_position(self, position: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Check if a specific position should be closed in emergency mode.
        
        Args:
            position: Position dictionary
            
        Returns:
            Tuple of (should_close: bool, reason: str)
        """
        if not self.emergency_shutdown:
            return False, "Not in emergency mode"
        
        # Always close profitable positions
        if float(position.get('profit', 0.0)) > 0:
            return True, "Emergency mode: Closing profitable position"
        
        # For losing positions, check recovery attempts
        if self.recovery_attempts >= self.max_recovery_attempts:
            return True, "Emergency mode: Max recovery attempts reached, force closing"
        
        return False, "Emergency mode: Waiting for recovery"
    
    def increment_recovery_attempt(self) -> None:
        """Increment recovery attempt counter."""
        self.recovery_attempts += 1
        logger.info(f"[RISK_GOVERNOR] Recovery attempt {self.recovery_attempts}/{self.max_recovery_attempts}")
        
        if self.recovery_attempts >= self.max_recovery_attempts:
            logger.critical("[RISK_GOVERNOR] Max recovery attempts reached - Initiating Chronos Protocol")
            self._trigger_chronos_signal("Max recovery attempts exhausted")
    
    def _trigger_chronos_signal(self, reason: str) -> None:
        """
        Trigger Chronos Protocol (Offload & Partition).
        Replaces 'Full Shutdown'.
        """
        if not self.emergency_shutdown:
            # We use the same flag to block immediate new trades until Offload is done.
            # But we mark reason as CHRONOS to tell TradingEngine what to do.
            self.emergency_shutdown = True
            self.shutdown_reason = f"CHRONOS_TRIGGER:{reason}"
            logger.critical(f"[RISK_GOVERNOR] ⏳ CHRONOS PROTOCOL TRIGGERED: {reason}")
            logger.critical("[RISK_GOVERNOR] Requesting IMMEDIATE OFFLOAD to Bad Bank.")
    
    def reset_emergency_mode(self, admin_password: str = "RESET_AETHER_2026") -> bool:
        """
        Reset emergency mode (requires admin password).
        """
        if admin_password == "RESET_AETHER_2026":
            self.valkyrie_active = False
            self.emergency_shutdown = False
            self.shutdown_reason = ""
            self.recovery_attempts = 0
            if hasattr(self, 'exit_strategy'):
                delattr(self, 'exit_strategy')
            logger.warning("[RISK_GOVERNOR] Valkyrie/Emergency mode RESET by admin")
            return True
        else:
            logger.error("[RISK_GOVERNOR] Invalid admin password for emergency reset")
            return False
    
    def get_risk_status(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Get current risk status without vetoing.
        """
        total_exposure_pct = float(metrics.get("total_exposure_pct", 0.0))
        total_positions = int(metrics.get("total_positions", 0))
        # account_drawdown_pct = float(metrics.get("account_drawdown_pct", 0.0))
        balance = float(metrics.get("balance", 10000.0))
        
        max_positions = self._calculate_dynamic_position_limit(balance)
        exposure_usage = total_exposure_pct / self.limits.max_total_exposure_pct if self.limits.max_total_exposure_pct > 0 else 0.0
        
        return {
            'valkyrie_active': self.valkyrie_active,
            'emergency_shutdown': self.emergency_shutdown,
            'recovery_attempts': self.recovery_attempts,
            'exposure_usage': exposure_usage,
            'position_usage': total_positions / max_positions if max_positions > 0 else 0.0,
            'drawdown_usage': 0.0,  # Simplified as we mostly care about Exposure/Valkyrie
            'max_positions_allowed': max_positions,
            'overall_risk_level': self._calculate_overall_risk(metrics)
        }
    
    def _calculate_overall_risk(self, metrics: Dict[str, Any]) -> str:
        """
        Calculate overall risk level.
        Returns: 'LOW', 'MEDIUM', 'HIGH', or 'CRITICAL'
        """
        total_exposure_pct = float(metrics.get("total_exposure_pct", 0.0))
        total_positions = int(metrics.get("total_positions", 0))
        account_drawdown_pct = float(metrics.get("account_drawdown_pct", 0.0))
        balance = float(metrics.get("balance", 10000.0))
        
        max_positions = self._calculate_dynamic_position_limit(balance)
        
        exposure_usage = total_exposure_pct / self.limits.max_total_exposure_pct if self.limits.max_total_exposure_pct > 0 else 0.0
        position_usage = total_positions / max_positions if max_positions > 0 else 0.0
        drawdown_usage = account_drawdown_pct / self.limits.max_drawdown_pct if self.limits.max_drawdown_pct > 0 else 0.0
        
        max_usage = max(exposure_usage, position_usage, drawdown_usage)
        
        if max_usage >= 0.90:
            return 'CRITICAL'
        elif max_usage >= 0.70:
            return 'HIGH'
        elif max_usage >= 0.50:
            return 'MEDIUM'
        else:
            return 'LOW'


# Singleton instance
_governor_instance: Optional[RiskGovernor] = None

def get_risk_governor(limits: Optional[RiskLimits] = None) -> RiskGovernor:
    """Get or create the singleton RiskGovernor instance."""
    global _governor_instance
    if _governor_instance is None:
        if limits is None:
            # [INSTITUTIONAL] Dynamic Capital Allocation
            # Micro accounts need more active capital for viability
            # Large accounts need more reserves for stability
            limits = RiskLimits(
                max_total_exposure_pct=0.35,  # 35% Max Margin
                max_drawdown_pct=0.25,  # 25% Hard Stop
                position_limit_per_1k=3,  # 3 positions per $1000
                news_lockout=True,  # Enable News Lockout
                capital_reserve_pct=0.60  # [DEFAULT] 60% Reserve (adjusted dynamically in veto())
            )
        _governor_instance = RiskGovernor(limits)
    return _governor_instance
