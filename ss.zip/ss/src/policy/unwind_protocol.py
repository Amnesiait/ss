
import logging
from dataclasses import dataclass

logger = logging.getLogger("UnwindProtocol")

class UnwindProtocol:
    """
    [SMART UNWIND]
    The "Nil Loss" Escape Hatch.
    If the Vault blocks a recovery trade, this protocol monitors the existing bucket.
    If price touches "Break Even" AND Kalman predicts a reversal -> EXIT IMMEDIATELY.
    """
    def should_exit(self, bucket_id: str, is_long: bool, net_pnl: float, trajectory) -> tuple[bool, str]:
        """
        Check if we should emergency exit at break-even.
        Args:
            trajectory: Trajectory object from KalmanSniper
        """
        if not trajectory:
            return False, ""

        # 1. The "Nil Loss" Zone
        # We accept a small loss ($-0.50) to escape a potential crash.
        # We obviously take any profit (>$0.00).
        is_safe_exit_zone = net_pnl > -0.50
        
        if not is_safe_exit_zone:
            # We are too deep in loss. Unwinding now guarantees a loss.
            # We must wait (or let Stop Loss hit).
            return False, ""

        # 2. The Kalman Signal
        # If we are Long, and Kalman says "SELL" (Price Deviation Down), valid escape.
        # If we are Short, and Kalman says "BUY" (Price Deviation Up), valid escape.
        
        escape_signal = False
        reason = ""
        
        if is_long:
            if trajectory.signal == "SELL":
                escape_signal = True
                reason = f"KALMAN_REVERSAL_DOWN (Dev: {trajectory.deviation:.2f})"
        else:
            if trajectory.signal == "BUY":
                escape_signal = True
                reason = f"KALMAN_REVERSAL_UP (Dev: {trajectory.deviation:.2f})"
                
        if escape_signal:
             return True, f"SMART_UNWIND[{reason}] PnL: ${net_pnl:.2f}"
             
        return False, ""
