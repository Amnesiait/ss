"""
AETHER Security Module

Provides license management and security enforcement for the trading bot.

Author: AETHER Development Team
Version: 1.0.0
"""

from .license_manager import LicenseManager, enforce_license, _license_mgr

__all__ = ['LicenseManager', 'enforce_license', '_license_mgr']
