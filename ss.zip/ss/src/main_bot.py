"""
AETHER Trading Bot - Refactored Main Entry Point

This module serves as the main entry point for the AETHER trading system,
now refactored into modular components for better maintainability and testing.

The bot orchestrates:
- Market data processing
- AI-driven trading decisions
- Risk management and position handling
- Configuration validation and security

Author: AETHER Development Team
Version: 7.6.6
"""

import asyncio
from datetime import datetime
import logging
import signal
import time
import os
import yaml
import json
import threading
from collections import deque
from typing import Dict, Any, Optional
from pathlib import Path

# Import modular components
from .market_data import MarketDataManager
from .position_manager import PositionManager
from .risk_manager import RiskManager, ZoneConfig
from .trading_engine import TradingEngine, TradingConfig
from .config_validator import ConfigValidator
from .utils.trading_logger import TradingLogger, DecisionTracker

# Import async database
from .infrastructure.async_database import get_async_database_manager

# Import NEW Intelligence Layers
from .ai_core.oracle import Oracle
from .utils.news_filter import NewsFilter
from .automation.auto_quant import AutoQuant # [NEW] Self-Improvement Module

# Import existing components (to be gradually migrated)

from .ai_core.ppo_guardian import PPOGuardian
from .ai_core.iron_shield import IronShield
from .ai_core.recovery_engine import RecoveryEngine
from .ai_core.kelly_criterion import KellyCriterion  # [PHASE 3]
from .infrastructure.database import get_database_manager
from .infrastructure.supabase_adapter import SupabaseAdapter
from .bridge.broker_factory import BrokerFactory

logger = logging.getLogger("AetherBot")

# Setup UI Logger for console output
ui_logger = logging.getLogger("AETHER_UI")
ui_logger.setLevel(logging.INFO)
if not ui_logger.handlers:
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    ui_logger.addHandler(console_handler)
    ui_logger.propagate = False

# Configure Trader Dashboard (Event-Driven Logging)
trader_logger = logging.getLogger("TRADER")
trader_logger.setLevel(logging.INFO)
if not trader_logger.handlers:
    trader_handler = logging.StreamHandler()
    trader_handler.setFormatter(logging.Formatter('%(message)s'))
    trader_logger.addHandler(trader_handler)
    trader_logger.propagate = False

# Suppress technical/internal logs to reduce noise
# Only show warnings and errors from these loggers
logging.getLogger("FRESHNESS").setLevel(logging.WARNING)
logging.getLogger("POS_MGMT").setLevel(logging.WARNING)
logging.getLogger("BUCKET").setLevel(logging.WARNING)
logging.getLogger("TP_CHECK").setLevel(logging.WARNING)
logging.getLogger("ZONE_CHECK").setLevel(logging.WARNING)
logging.getLogger("SYNC").setLevel(logging.WARNING)
logging.getLogger("PLAN").setLevel(logging.WARNING)
logging.getLogger("CLOSE").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

# Additional noise suppression
logging.getLogger("PositionManager").setLevel(logging.WARNING)
logging.getLogger("TradingEngine").setLevel(logging.WARNING)
logging.getLogger("RiskManager").setLevel(logging.WARNING)
logging.getLogger("MarketData").setLevel(logging.WARNING)
logging.getLogger("MetaTrader5").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)
logging.getLogger("asyncio").setLevel(logging.WARNING)
logging.getLogger("mt5").setLevel(logging.WARNING)
logging.getLogger("Oracle").setLevel(logging.WARNING)
logging.getLogger("HedgeCoordinator").setLevel(logging.WARNING)
logging.getLogger("AsyncDatabase").setLevel(logging.WARNING)


class AetherBot:
    """
    Main AETHER trading bot class with modular architecture.

    This class orchestrates all trading activities using specialized modules:
    - MarketDataManager: Data fetching and market state tracking
    - PositionManager: Position tracking and bucket management
    - RiskManager: Zone recovery and hedging logic
    - TradingEngine: Core trading decision and execution
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the AETHER trading bot.

        Args:
            config: Complete configuration dictionary
        """
        self.config = config
        self.running = False

        # [PHASE 3] Kelly Criterion - Initialize early
        from .ai_core.kelly_criterion import KellyCriterion
        self.kelly_engine = KellyCriterion()

        # Core components

        self.broker = None
        self.market_data = None
        self.trading_engine: Optional[TradingEngine] = None
        self.market_data: Optional[MarketDataManager] = None
        
        # [ZERO-LOSS] Recovery Engine
        self.recovery_engine = RecoveryEngine()
        logger.info("[INIT] Recovery Engine initialized")
        self.trading_engine = None

        # Legacy components (to be migrated)
        self.nexus = None
        self.ppo_guardian = None
        self.council = None
        self.shield = None
        self.strategist = None
        self.memory_db = None
        self.supabase_adapter = None

        # Control flags
        self.shutdown_requested = False
        
        # Dashboard timer
        self.last_console_update = 0.0
        self.console_update_interval = 10.0  # Seconds
        
        # Maintenance state
        self.last_maintenance_date = None
        
        # Decision tracking for rolling logs (reduces noise)
        self.decision_tracker = DecisionTracker()

        # Decision tracking for rolling logs (reduces noise)
        self.decision_tracker = DecisionTracker()

        # Automation
        self.auto_quant = AutoQuant()
        
        # [WIRING] Bayesian Tuner Injection
        # Tuner is passed from launcher to ensure optimization data persists across restarts
        self.tuner = config.get('tuner_instance')
        if self.tuner:
            logger.info("[WIRING] Bayesian Tuner Connected to Bot Context")

        logger.info("AETHER Bot initialized")

    def validate_configuration(self) -> bool:
        """
        Validate configuration with security checks.

        Returns:
            True if configuration is valid and secure
        """
        validator = ConfigValidator()

        # Validate main config
        is_valid, errors, warnings = validator.validate_all()

        # Log warnings
        for warning in warnings:
            logger.warning(f"Config Warning: {warning}")

        # Log errors
        if errors:
            for error in errors:
                logger.error(f"Config Error: {error}")
            return False

        # Security validation
        is_secure, security_issues = validator.validate_secure_config_loading(self.config)
        if not is_secure:
            for issue in security_issues:
                logger.error(f"Security Issue: {issue}")
            return False

        logger.info("[OK] Configuration validation passed")
        return True

    async def initialize_components(self) -> bool:
        """
        Initialize all bot components.

        Returns:
            True if all components initialized successfully
        """
        try:
            # Initialize broker
            logger.info("1. Connecting to Broker...")
            broker_type = self.config.get('trading', {}).get('broker_type', 'MT5')
            credentials = self._extract_credentials()
            self.broker = BrokerFactory.get_broker(broker_type, credentials)

            if not self.broker.connect():
                logger.error(f"Failed to connect to {broker_type}")
                return False

            # Initialize modular components
            logger.info("2. Initializing Market Data & Position Manager...")
            timeframe = self.config.get('trading', {}).get('timeframe', 'M1')
            self.market_data = MarketDataManager(self.broker, timeframe, self.config)

            # v5.5.0: Pass broker to PositionManager for Architect
            self.position_manager = PositionManager(
                mt5_adapter=self.broker,
                kelly_engine=self.kelly_engine  # [PHASE 3]
            )
            
            # CRITICAL: Sync position state with broker to remove stale positions
            logger.info("3. Synchronizing Positions...")
            broker_positions = self.broker.get_positions()
            if broker_positions is not None:
                self.position_manager.cleanup_stale_positions(broker_positions)
                # Update bucket stats to mark empty buckets as closed
                self.position_manager._update_bucket_stats()
                self.position_manager.update_positions(broker_positions)
                logger.info(f"[SYNC] Position manager synchronized with broker: {len(broker_positions)} active positions")
            else:
                logger.warning("[SYNC] Failed to fetch initial positions from broker")

            # [FIX] Define config objects before use
            bot_trading_config = TradingConfig(
                symbol=self.config.get('trading', {}).get('symbol', 'EURUSD'),
                initial_lot=self.config.get('risk', {}).get('initial_lot', 0.01),
                global_trade_cooldown=5.0, # Reduced for Continuous Scalping
                timeframe=self.config.get('trading', {}).get('timeframe', 'M1')
            )

            zone_config = ZoneConfig(
                zone_pips=self.config.get('risk', {}).get('zone_recovery', {}).get('zone_pips', 25),
                tp_pips=self.config.get('risk', {}).get('zone_recovery', {}).get('tp_pips', 25),
                max_hedges=self.config.get('risk', {}).get('zone_recovery', {}).get('max_layers', 6)
            )
            
            self.risk_manager = RiskManager(
                zone_config,
                broker=self.broker,
                symbol=bot_trading_config.symbol
            )
            
            # [FIX] Initialize IronShield early and attach to RiskManager
            self.shield = IronShield(
                initial_lot=self.config['risk']['initial_lot'],
                zone_pips=self.config['risk']['zone_recovery']['zone_pips'],
                tp_pips=self.config['risk']['zone_recovery']['tp_pips'],
                kelly_engine=self.kelly_engine  # [PHASE 3]
            )
            # Attach shield to risk_manager
            self.risk_manager.shield = self.shield

            # Initialize async database
            logger.info("4. Connecting to Database...")
            db_manager = await get_async_database_manager(self.config.get('database'))

            logger.info("5. Initializing AI Core (This is the heavy part)...")
            
            # Initialize AI components needed for TradingEngine
            print(">>> [INIT] Loading PPO Guardian (Reinforcement Learning)...", flush=True)
            self.ppo_guardian = PPOGuardian()
            print(">>> [INIT] PPO Guardian Online.", flush=True)
            
            # Initialize Global Brain (Layer 9)
            print(">>> [INIT] Loading Global Brain (Macro Analysis)...", flush=True)
            from .ai_core.global_brain import GlobalBrain
            self.global_brain = GlobalBrain(self.market_data)
            print(">>> [INIT] Global Brain Online.", flush=True)

            # v5.5.0: Initialize TickPressureAnalyzer shared instance
            from .ai_core.tick_pressure import TickPressureAnalyzer
            self.tick_analyzer = TickPressureAnalyzer()

            # Initialize News Filter (The Sentinel) - CRITICAL FIX for AttributeError
            self.news_filter = NewsFilter()

            # Initialize Oracle (Layer 4)
            print(">>> [INIT] Loading Oracle (Price Prediction)...", flush=True)
            # v5.5.0: Pass broker and tick_analyzer to Oracle
            self.oracle = Oracle(mt5_adapter=self.broker, tick_analyzer=self.tick_analyzer, global_brain=self.global_brain)
            print(">>> [INIT] Oracle Online.", flush=True)

            print(">>> [INIT] Starting Trading Engine...", flush=True)
            self.trading_engine = TradingEngine(bot_trading_config, self.broker, self.market_data,
                                              self.position_manager, self.risk_manager, db_manager, self.ppo_guardian, self.global_brain,
                                              tick_analyzer=self.tick_analyzer, recovery_engine=self.recovery_engine)
            print(">>> [INIT] Trading Engine Ready.", flush=True)
            
            # INTEGRATION FIX: Pass model_monitor to Oracle after trading_engine is initialized
            if hasattr(self.trading_engine, 'model_monitor') and self.trading_engine.model_monitor:
                self.oracle.model_monitor = self.trading_engine.model_monitor
                logger.info("[INTEGRATION] Model monitor connected to Oracle")

            # Initialize database components
            print(">>> [INIT] Initializing Database...", flush=True)
            await self.trading_engine.initialize_database()
            print(">>> [INIT] Database Initialized.", flush=True)

            # Initialize legacy components (temporary)
            logger.info("6. Finalizing Setup...")
            print(">>> [INIT] Initializing Legacy Components...", flush=True)
            self._initialize_legacy_components()
            print(">>> [INIT] Legacy Components Initialized.", flush=True)

            logger.info("[OK] All components initialized successfully")
            return True

        except Exception as e:
            import sys
            sys.stderr.write(f"INIT ERROR: {e}\n")
            logger.error(f"Component initialization failed: {e}")
            return False

    def _extract_credentials(self) -> Dict[str, str]:
        """Extract broker credentials from config."""
        credentials = {}

        # Try to get from environment first (secure)
        credentials.update({
            'mt5_login': os.getenv('MT5_LOGIN'),
            'mt5_password': os.getenv('MT5_PASSWORD'),
            'mt5_server': os.getenv('MT5_SERVER'),
            'api_key': os.getenv('API_KEY'),
            'secret_key': os.getenv('SECRET_KEY')
        })

        # Fallback to config (less secure)
        if not credentials['mt5_login']:
            credentials.update({
                'mt5_login': self.config.get('mt5_login'),
                'mt5_password': self.config.get('mt5_password'),
                'mt5_server': self.config.get('mt5_server'),
                'api_key': self.config.get('api_key'),
                'secret_key': self.config.get('secret_key')
            })

        return credentials

    def _initialize_legacy_components(self) -> None:
        """Initialize legacy components (to be migrated to modular system)."""
        logger.info("Initializing legacy AI components (Nexus Brain, Iron Shield)...")

        # AI Components

        # self.ppo_guardian is already initialized in initialize_components

        # Risk and Strategy
        # self.shield is already initialized in initialize_components

        # Infrastructure
        self.memory_db = get_database_manager(self.config.get('database'))
        self.supabase_adapter = SupabaseAdapter()

    def _setup_signal_handlers(self) -> None:
        """Setup graceful shutdown signal handlers."""
        def signal_handler(signum, frame):
            logger.info(f"Shutdown signal received ({signum}). Initiating graceful shutdown...")
            self.shutdown_requested = True

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

    async def run(self) -> None:
        """
        Main bot execution loop.
        """
        if not self.validate_configuration():
            logger.error("Configuration validation failed. Exiting.")
            return

        if not await self.initialize_components():
            logger.error("Component initialization failed. Exiting.")
            return

        self._setup_signal_handlers()
        self.running = True

        logger.info("[INFO] AETHER Trading System Online")
        print(">>> [SYSTEM] Bot is Running. Waiting for market data...", flush=True)
        logger.info("=" * 50)

        try:
            print(">>> [DEBUG] Entering Main Loop...", flush=True)
            last_heartbeat = time.time()
            while not self.shutdown_requested:
                # 0. EMERGENCY HEALTH CHECK (The "Hard Stop")
                # Prevents total account blowup (User Objective)
                if not await self._monitor_equity_health():
                    logger.critical("🚨 EMERGENCY SHUTDOWN TRIGGERED BY EQUITY PROTECTION 🚨")
                    break

                # Heartbeat every 10 seconds (Log only, no print)
                if time.time() - last_heartbeat > 60.0:
                    # print(f">>> [SYSTEM] Heartbeat - Bot is alive. Time: {time.strftime('%H:%M:%S')}", flush=True)
                    last_heartbeat = time.time()

                await self._run_trading_cycle()

                # [AUTOMATION] Maintenance & Self-Improvement
                await self._check_weekend_maintenance()
                await self._check_daily_maintenance()

                # Adaptive sleep: Balanced latency for active positions
                has_positions = len(self.position_manager.active_positions) > 0
                if has_positions:
                    # Active positions mode: 100ms polling (10Hz) - fast enough for scalping without overloading broker
                    # Provides <100ms response time while reducing race conditions and API load
                    await asyncio.sleep(0.1) 
                else:
                    # Normal adaptive sleep when waiting for signals (0.1s - 1.0s)
                    sleep_time = self.market_data.get_adaptive_sleep_time()
                    await asyncio.sleep(min(sleep_time, 0.5)) # Cap at 0.5s to catch signals faster

        except Exception as e:
            logger.error(f"Critical error in main loop: {e}")
        finally:
            await self._shutdown()
            logger.info("AETHER System shutdown complete")

    async def _run_trading_cycle(self) -> None:
        """
        Execute one complete trading cycle.
        """
        try:
            logger.debug("[CYCLE] TRADING CYCLE START")

            # [THE VAULT] Check if Training is active (Block Trading)
            if getattr(self, '_auto_quant_running', False):
                # We skip trading to prioritize AI Brain CPU/GPU cycles
                # But we still update the dashboard so the user sees progress
                await self._update_dashboard()
                return

            # Trading engine handles position management AND new entries in single call
            await self._execute_trading_strategy()

            # Update dashboard and logs
            await self._update_dashboard()
            
            # Safe Garbage Collection
            # Only clean memory if we are FLAT (no open trades) to avoid lag spikes during trading
            # [OPTIMIZATION] Removed frequent GC calls. Python's cyclic GC is sufficient.
            # Only force collect if necessary during idle times (implemented elsewhere if needed).
            pass

            logger.debug("[SUCCESS] TRADING CYCLE COMPLETED")

        except Exception as e:
            print(f">>> [ERROR] Cycle Error: {e}", flush=True)
            logger.error(f"[FAIL] TRADING CYCLE ERROR: {e}")

    async def _execute_trading_strategy(self) -> None:
        """Execute trading strategy for new entries."""
        # Use the new trading engine
        await self.trading_engine.run_trading_cycle(
            self.shield, self.ppo_guardian, self.nexus, self.oracle
        )

    async def _update_dashboard(self) -> None:
        """Update dashboard with current status."""
        try:
            # Get dashboard stats
            stats = self.trading_engine.get_session_stats()

            # Update Console Dashboard (Periodic)
            current_time = time.time()
            if current_time - self.last_console_update >= self.console_update_interval:
                self._print_console_status()
                self.last_console_update = current_time

            # Update via Supabase if enabled
            if self.supabase_adapter and self.supabase_adapter.enabled:
                await self.supabase_adapter.push_system_status({
                    "status": "ACTIVE" if self.running else "STOPPED",
                    "trades_opened": stats.get("trades_opened", 0),
                    "trades_closed": stats.get("trades_closed", 0),
                    "total_profit": stats.get("total_profit", 0.0),
                    "timestamp": int(time.time() * 1000)
                })

        except Exception as e:
            logger.error(f"Dashboard update failed: {e}")

    async def _monitor_equity_health(self) -> bool:
        """
        [INSTITUTIONAL CIRCUIT BREAKER] Shadow-Relative Hard Stop.
        
        Protects 75-80% of total capital by using Shadow Balance calculation.
        Triggers at 50% loss of ACTIVE capital, not total capital.
        
        Example: $1500 account with 50% active ratio:
        - Shadow Balance: $750 (active)
        - Reserved Capital: $750 (frozen)
        - Circuit Trigger: $1500 - ($750 * 0.5) = $1125
        - Protection: 75% of total capital preserved
        """
        try:
            if not self.broker: return True
            
            acct = self.broker.get_account_info()
            if not acct: return True
            
            equity = float(acct.get('equity', 0.0))
            balance = float(acct.get('balance', 0.0))
            
            if balance <= 0: return True
            
            # [INSTITUTIONAL] Calculate Dynamic Capital Allocation
            # Micro accounts get more active capital, large accounts get more reserve
            if balance < 2000:
                active_ratio = 0.50  # 50% active for micro accounts
            elif balance < 5000:
                active_ratio = 0.45  # 45% active
            elif balance < 10000:
                active_ratio = 0.40  # 40% active
            else:
                active_ratio = 0.35  # 35% active for professional accounts
            
            # Calculate Shadow Metrics
            shadow_balance = balance * active_ratio
            reserved_capital = balance - shadow_balance
            max_shadow_loss = shadow_balance * 0.50  # Allow 50% loss of active capital only
            circuit_trigger = balance - max_shadow_loss
            
            # Calculate drawdowns for logging
            real_drawdown_pct = (balance - equity) / balance if balance > 0 else 0.0
            shadow_loss = balance - equity
            shadow_drawdown_pct = shadow_loss / shadow_balance if shadow_balance > 0 else 0.0
            
            # CIRCUIT BREAKER: Shadow-Relative
            if equity < circuit_trigger:
                logger.critical(f"🚨 INSTITUTIONAL CIRCUIT BREAKER TRIGGERED")
                logger.critical(f"   Real Equity: ${equity:.2f} < Trigger: ${circuit_trigger:.2f}")
                logger.critical(f"   Real Drawdown: {real_drawdown_pct:.1%} | Shadow DD: {shadow_drawdown_pct:.1%}")
                logger.critical(f"   Active Capital: ${shadow_balance:.2f} | Reserved: ${reserved_capital:.2f}")
                
                # [ZERO-LOSS] Activate Recovery Engine instead of shutdown
                total_loss = balance - equity
                
                # [FIX 1] Get all current positions to freeze (NOT async)
                frozen_positions = []
                if self.position_manager:
                    all_positions = self.broker.get_positions()
                    if all_positions:
                        frozen_positions = [p for p in all_positions if p.get('profit', 0) < 0]
                else:
                    logger.error("[RECOVERY] Cannot activate: PositionManager not initialized")
                    # Fallback to shutdown
                    logger.critical(f"💀 INITIATING EMERGENCY LIQUIDATION (Protecting ${reserved_capital:.2f})")
                    self.running = False
                    self.shutdown_requested = True
                    return False
                
                logger.critical(f"💡 [RECOVERY] Attempting zero-loss recovery instead of shutdown")
                logger.critical(f"   Strategy: Volatility Harvesting (Ultra-conservative scalping)")
                logger.critical(f"   Debt Target: ${total_loss:.2f}")
                logger.critical(f"   Free Margin: ${circuit_trigger - reserved_capital:.2f} available")
                
                # [FIX 2] FREEZE positions using Valkyrie Perfect Hedge BEFORE recovery
                frozen_count = 0
                if frozen_positions:
                    logger.critical(f"[RECOVERY] Executing Valkyrie Perfect Hedge on {len(frozen_positions)} positions")
                    for pos in frozen_positions:
                        bucket_id = pos.get('bucket_id')
                        if bucket_id:
                            try:
                                # Call Valkyrie Perfect Hedge to freeze this bucket
                                freeze_success = await self.position_manager.execute_perfect_hedge(
                                    broker=self.broker,
                                    bucket_id=bucket_id
                                )
                                if freeze_success:
                                    frozen_count += 1
                                    logger.info(f"[RECOVERY] ❄️ Froze bucket {bucket_id}")
                                else:
                                    logger.warning(f"[RECOVERY] Failed to freeze bucket {bucket_id}")
                            except Exception as e:
                                logger.error(f"[RECOVERY] Error freezing bucket {bucket_id}: {e}")
                    logger.critical(f"[RECOVERY] Successfully froze {frozen_count}/{len(frozen_positions)} buckets")
                
                # Activate recovery mode
                recovery_activated = self.recovery_engine.activate_recovery(
                    frozen_positions=frozen_positions,
                    total_loss=total_loss,
                    account_equity=equity
                )
                
                if recovery_activated:
                    logger.critical(f"✅ [RECOVERY] Mode activated. Bot will scalp to recover ${total_loss:.2f}")
                    logger.critical(f"   Frozen {frozen_count} buckets with Valkyrie hedge")
                    logger.critical(f"   Will exit recovery when debt paid to $0")
                    # Continue running in recovery mode (don't shutdown)
                else:
                    logger.error(f"❌ [RECOVERY] Activation failed. Proceeding with emergency liquidation.")
                    logger.critical(f"💀 INITIATING EMERGENCY LIQUIDATION (Protecting ${reserved_capital:.2f})")
                    
                    # Fallback to shutdown if recovery fails
                    await self.position_manager.close_all_positions(reason="CIRCUIT_BREAKER_SHADOW")
                    
                    # SHUTDOWN
                    self.running = False
                    self.shutdown_requested = True
                    logger.critical(f"⛔ BOT SHUTDOWN: {reserved_capital/balance:.0%} of capital preserved")
                    return False
            
            return True
        except Exception as e:
            logger.error(f"Equity health check failed: {e}")
            return True

    def _print_console_status(self) -> None:
        """Print a clean status dashboard to the console."""
        # DISABLED: User requested to disable rolling logs
        return

    async def _check_weekend_maintenance(self) -> None:
        """
        Check if we are in a weekend window and run self-improvement.
        Auto-runs AutoQuant on Saturdays/Sundays once per day.
        """
        now = datetime.now()
        is_weekend = now.weekday() >= 5 # 5=Sat, 6=Sun
        
        # Check if already ran today
        today_str = now.strftime("%Y-%m-%d")
        if getattr(self, '_last_weekend_maintenance', None) == today_str:
            return
            
        if is_weekend:
            # Check for idle state (no positions)
            if len(self.position_manager.active_positions) > 0:
                return # Wait for flat state

            logger.info(f"[MAINTENANCE] Weekend Detected ({now.strftime('%A')}). Initiating Self-Improvement Protocol...")
            print(f">>> [SYSTEM] Weekend Maintenance: Training Oracle Model...", flush=True)
            
            # Run in thread to avoid blocking heartbeat
            try:
                await asyncio.to_thread(self.auto_quant.run_cycle)
                self._last_weekend_maintenance = today_str
                print(f">>> [SYSTEM] Maintenance Complete. Model Updated.", flush=True)
            except Exception as e:
                logger.error(f"Maintenance failed: {e}")

    async def _check_daily_maintenance(self) -> None:
        """
        Check for daily maintenance window (Idle + Sentinel News Blackout).
        Runs training when the bot has no open positions and is in a News Blackout.
        """
        now = datetime.now()
        today_str = now.strftime("%Y-%m-%d")
        
        # Check if already ran today
        if self.last_maintenance_date == today_str:
            return
            
        # [CRITICAL] 1. Idle Check: Only train when FLAT (No open positions)
        if len(self.position_manager.active_positions) > 0:
            return
            
        # 2. Sentinel Check: Trigger during News Blackouts (as requested by user)
        is_safe, reason = self.news_filter.check_status()
        is_blackout = (not is_safe) and ("SENTINEL_BLOCK" in reason)
        
        if is_blackout:
            if not getattr(self, '_auto_quant_running', False):
                self._auto_quant_running = True
                logger.info(f"[MAINTENANCE] Sentinel Blackout Detected ({reason}). Initiating Training...")
                print(f">>> [SYSTEM] Sentinel Maintenance: Retraining AI Brain (Model Tracking)...", flush=True)
                
                try:
                    # Run training in background task so we don't stall the heartbeat
                    asyncio.create_task(self._run_auto_quant_cycle_with_marking(today_str))
                except Exception as e:
                    logger.error(f"Daily maintenance failed: {e}")
                    self._auto_quant_running = False

    async def _run_auto_quant_cycle_with_marking(self, date_str: str) -> None:
        """Wrapper to mark completion after successful run."""
        try:
            await asyncio.to_thread(self.auto_quant.run_cycle)
            self.last_maintenance_date = date_str
            print(f">>> [SYSTEM] Daily Training Complete.", flush=True)
        except Exception as e:
            logger.error(f"Training cycle error: {e}")
        finally:
            self._auto_quant_running = False

    async def _run_auto_quant_cycle(self) -> None:
        """Run Auto-Quant cycle asynchronously."""
        try:
            logger.info("[AUTO-QUANT] Starting Periodic Self-Improvement Cycle...")
            await asyncio.to_thread(self.auto_quant.run_cycle)
            logger.info("[AUTO-QUANT] Cycle Complete.")
        except Exception as e:
            logger.error(f"[AUTO-QUANT] Cycle Failed: {e}")
        finally:
            self._auto_quant_running = False

    async def _shutdown(self) -> None:
        """Perform graceful shutdown."""
        logger.info("Performing graceful shutdown...")

        self.running = False

        # -------------------------------
        # End-of-session learning (daily)
        # -------------------------------
        # Goal: maximize profit while penalizing drawdown, without changing live weights intraday.
        try:
            enable_tuner = str(os.getenv("AETHER_ENABLE_SESSION_TUNING", "1")).strip().lower() in (
                "1",
                "true",
                "yes",
                "on",
            )
            if enable_tuner and getattr(self, "oracle", None) is not None and getattr(self.oracle, "tuner", None) is not None:
                stats = self.trading_engine.get_session_stats() if self.trading_engine else {}
                total_profit = float((stats or {}).get("total_profit", 0.0) or 0.0)
                max_dd_pct = float((stats or {}).get("max_drawdown_pct", 0.0) or 0.0)

                acct = self.broker.get_account_info() if self.broker else {}
                balance = float((acct or {}).get("balance", 0.0) or 0.0)
                # Penalty is scaled by starting/ending balance; if unknown, fall back to 0.
                if balance <= 0:
                    balance = 0.0

                try:
                    dd_lambda = float(os.getenv("AETHER_TUNER_DD_LAMBDA", "0.75"))
                except Exception:
                    dd_lambda = 0.75

                try:
                    cost_per_trade = float(os.getenv("AETHER_TUNER_COST_PER_TRADE", "0.0"))
                except Exception:
                    cost_per_trade = 0.0

                trades_closed = float((stats or {}).get("trades_closed", 0) or 0)

                # Risk-adjusted reward: profit minus drawdown penalty (scaled by balance) minus per-trade friction.
                dd_penalty = dd_lambda * (balance * max_dd_pct)
                reward = total_profit - dd_penalty - (cost_per_trade * trades_closed)

                params = getattr(self.oracle, "last_tuner_params", None)
                if isinstance(params, dict) and params:
                    self.oracle.tuner.report_result(params, pnl=float(reward))
                    logger.info(
                        f"[SESSION_TUNING] Reported reward=${reward:.2f} pnl=${total_profit:.2f} dd_pct={max_dd_pct*100:.2f}% dd_penalty=${dd_penalty:.2f} trades_closed={int(trades_closed)}"
                    )
                else:
                    logger.info("[SESSION_TUNING] Skipped: no tuner params recorded this session")
        except Exception as e:
            logger.warning(f"[SESSION_TUNING] Failed: {e}")

        # Optional: offline PPO evolution (explicitly gated)
        try:
            enable_ppo_evolve = str(os.getenv("AETHER_ENABLE_PPO_EVOLVE", "0")).strip().lower() in (
                "1",
                "true",
                "yes",
                "on",
            )
            if enable_ppo_evolve and self.ppo_guardian is not None:
                # Avoid evolving while trades are still open (incomplete episodes)
                open_positions = 0
                try:
                    pos = self.broker.get_positions() if self.broker else []
                    open_positions = len(pos) if pos else 0
                except Exception:
                    open_positions = 0

                if open_positions == 0:
                    ok = bool(self.ppo_guardian.evolve())
                    logger.info(f"[PPO_EVOLVE] Completed ok={ok} experiences={self.ppo_guardian.get_experience_count()}")
                else:
                    logger.info(f"[PPO_EVOLVE] Skipped (open_positions={open_positions})")
        except Exception as e:
            logger.warning(f"[PPO_EVOLVE] Failed: {e}")

        # Shutdown trading engine database
        if self.trading_engine:
            await self.trading_engine.shutdown_database()

        # Close database connections
        if self.memory_db:
            self.memory_db.close()

        # Disconnect broker
        if self.broker:
            self.broker.disconnect()

        logger.info("Shutdown complete")


def load_configuration() -> Dict[str, Any]:
    """
    Load and validate configuration from files.

    Returns:
        Configuration dictionary
    """
    config = {}

    # Load settings.yaml
    settings_file = Path("config/settings.yaml")
    if settings_file.exists():
        with open(settings_file, 'r') as f:
            config.update(yaml.safe_load(f) or {})

    # Load model_config.json
    model_config_file = Path("config/model_config.json")
    if model_config_file.exists():
        with open(model_config_file, 'r') as f:
            config['model_config'] = json.load(f)

    # Load user_config.json
    user_config_file = Path("config/user_config.json")
    if user_config_file.exists():
        with open(user_config_file, 'r') as f:
            config['user_config'] = json.load(f)

    return config


async def main(tuner=None):
    """
    Main entry point for the AETHER trading system.
    """
    # Load configuration
    config = load_configuration()
    
    # Inject Tuner if provided
    if tuner:
        config['tuner_instance'] = tuner

    # Create and run bot
    bot = AetherBot(config)
    await bot.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
