import datetime
import logging
from dataclasses import dataclass

logger = logging.getLogger("TheSentinel")

@dataclass
class BlackoutWindow:
    __slots__ = ['name', 'start_time', 'end_time']
    name: str
    start_time: float  # Format: HH.MM (e.g., 12.92 for 12:55)
    end_time: float    # Format: HH.MM
    
    def is_active(self, current_hour_float: float) -> bool:
        return self.start_time <= current_hour_float <= self.end_time

class NewsFilter:
    """
    [THE SENTINEL]
    Hard-Coded News Filter replacing GenAI.
    Blocks NFP, CPI, and FOMC via Strict Time Windows.
    
    CRITICAL TIME WINDOWS (UTC):
    1. US Open / High Impact (12:55 - 14:05)
       - Catches Non-Farm Payrolls (NFP) released at 13:30.
       - Catches CPI/PPI releases at 13:30.
       - Catches Market Open volatility at 13:30/14:30.
       
    2. FOMC / Fed Rate (18:50 - 20:00)
       - Catches FOMC Statement at 19:00.
       - Catches Fed Chair Press Conference at 19:30.
    """
    def __init__(self):
        # Time Management
        self.windows = [
            # Window A: US Open / NFP / CPI (13:15 UTC to 13:45 UTC)
            # [OPTIMIZED] 30-Minute Sniper Window
            # 13:15 = 13.25
            # 13:45 = 13.75
            # Captures 13:30 Release ±15 min buffer.
            BlackoutWindow("US_OPEN_NFP_CPI", 13.25, 13.75),
            
            # Window B: FOMC / Fed Interest Rates (18:50 UTC to 20:00 UTC)
            # 18:50 = 18 + 50/60 = 18.833
            # 20:00 = 20.0
            BlackoutWindow("FOMC_FED_RATE", 18.83, 20.01)
        ]
        logger.info("[SENTINEL] Hard-coded Blackout Windows initialized.")

    def check_status(self) -> tuple[bool, str]:
        """
        Main check called by TradingEngine.
        Returns: (is_safe, reason)
        """
        now = datetime.datetime.utcnow()
        current_float = now.hour + (now.minute / 60.0)
        
        # 1. Weekend Block (Fri 21:00 UTC - Sun 21:00 UTC)
        if now.weekday() == 4 and now.hour >= 21: return False, "MARKET_CLOSED_WEEKEND"
        if now.weekday() == 5: return False, "MARKET_CLOSED_WEEKEND"
        if now.weekday() == 6 and now.hour < 21: return False, "MARKET_CLOSED_WEEKEND"

        # 2. Sentinel Windows
        for window in self.windows:
            if window.is_active(current_float):
                return False, f"SENTINEL_BLOCK: {window.name} ({window.start_time:.2f}-{window.end_time:.2f} UTC)"
        
        return True, "SAFE"

    def is_pre_clearance_mode(self) -> bool:
        """
        Tick Check: Are we 5 minutes before a Blackout?
        Used for 'Smart Unwind' - exiting at break-even before the storm.
        """
        now = datetime.datetime.utcnow()
        current_float = now.hour + (now.minute / 60.0)
        
        # Check 5 mins before any window (0.083 hours)
        PRE_BUFFER = 0.083 
        
        for window in self.windows:
            # If we are in the zone [Start - 5min, Start]
            dist = window.start_time - current_float
            if 0 < dist < PRE_BUFFER:
                return True
        return False
