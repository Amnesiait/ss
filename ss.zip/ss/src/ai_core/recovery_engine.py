"""
Zero-Loss Recovery Engine: Volatility Harvesting System

This module implements institutional-grade loss recovery through ultra-conservative
scalping to pay off frozen position debt without adding capital risk.

Core Concept:
    When circuit breaker is triggered (e.g., -$375 loss):
    1. Freeze losing positions (Valkyrie Lock)
    2. Calculate debt target
    3. Execute micro-scalping with free margin
    4. Every profit goes to debt repayment
    5. Close frozen positions when debt = $0

Author: AETHER Development Team
Version: 1.0.0
"""

from enum import Enum
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import logging

logger = logging.getLogger("RecoveryEngine")


class RecoveryState(Enum):
    """Recovery mode states"""
    NORMAL = "normal"           # No recovery needed
    RECOVERY = "recovery"       # Active debt repayment
    COMPLETED = "completed"     # Debt paid, cleaning up


@dataclass
class RecoveryMetrics:
    """Track recovery progress"""
    debt_target: float = 0.0         # Total loss to recover
    debt_paid: float = 0.0           # Amount recovered so far
    recovery_trades: int = 0         # Number of scalps executed
    successful_trades: int = 0       # Winning scalps
    failed_trades: int = 0           # Losing scalps
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    @property
    def debt_remaining(self) -> float:
        """Calculate remaining debt"""
        return max(0.0, self.debt_target - self.debt_paid)
    
    @property
    def recovery_rate(self) -> float:
        """Calculate recovery percentage"""
        if self.debt_target <= 0:
            return 0.0
        return (self.debt_paid / self.debt_target) * 100.0
    
    @property
    def win_rate(self) -> float:
        """Calculate recovery trade win rate"""
        total = self.successful_trades + self.failed_trades
        if total == 0:
            return 0.0
        return (self.successful_trades / total) * 100.0


class RecoveryEngine:
    """
    Zero-Loss Recovery System using Volatility Harvesting.
    
    Strategy:
        - Freeze losing positions to lock current loss
        - Use free margin for ultra-conservative scalping
        - Only take PERFECT setups (Oracle + RSI + MACD all agree)
        - Micro lot sizes (0.01) with tight TPs (3-5 pips)
        - Track every profit toward debt repayment
        - Exit recovery mode when debt fully paid
    """
    
    def __init__(self):
        self.state = RecoveryState.NORMAL
        self.metrics = RecoveryMetrics()
        self.frozen_position_ids: List[int] = []
        self.recovery_trade_ids: List[int] = []
        
        # Recovery parameters (ULTRA-CONSERVATIVE)
        self.min_oracle_confidence = 0.80      # Very high confidence required
        self.min_rsi_safe_zone = (35, 65)      # Only trade in safe RSI range
        self.max_recovery_lot = 0.01           # Micro lots only
        self.target_pips_per_trade = 5.0       # Tight TP for quick exits
        self.max_concurrent_recovery = 2       # Max 2 recovery trades at once
        
    def activate_recovery(self, 
                         frozen_positions: List[Dict], 
                         total_loss: float,
                         account_equity: float) -> bool:
        """
        Activate recovery mode.
        
        Args:
            frozen_positions: List of positions to freeze
            total_loss: Total unrealized loss to recover
            account_equity: Current account equity
            
        Returns:
            True if recovery activated successfully
        """
        if self.state == RecoveryState.RECOVERY:
            logger.warning("[RECOVERY] Already in recovery mode")
            return False
            
        if total_loss <= 0:
            logger.error("[RECOVERY] Invalid loss amount: ${total_loss:.2f}")
            return False
        
        # Initialize recovery session
        self.state = RecoveryState.RECOVERY
        self.metrics = RecoveryMetrics(
            debt_target=abs(total_loss),
            started_at=datetime.now()
        )
        
        # Store frozen position IDs
        self.frozen_position_ids = [pos.get('ticket', pos.get('id', 0)) 
                                   for pos in frozen_positions]
        
        logger.critical(f"🔄 [RECOVERY] ACTIVATED")
        logger.critical(f"   Debt Target: ${self.metrics.debt_target:.2f}")
        logger.critical(f"   Frozen Positions: {len(self.frozen_position_ids)}")
        logger.critical(f"   Current Equity: ${account_equity:.2f}")
        logger.critical(f"   Strategy: Ultra-conservative volatility harvesting")
        
        return True
    
    def get_adaptive_tp(self, base_atr_pips: float = None) -> float:
        """
        Calculate adaptive TP based on recovery progress.
        Tighter TPs for faster debt repayment.
        """
        if self.state != RecoveryState.RECOVERY:
            return 25.0
        
        progress = self.metrics.debt_paid / self.metrics.debt_target if self.metrics.debt_target > 0 else 1.0
        
        if progress < 0.25:
            return 10.0  # EARLY
        elif progress < 0.75:
            return 8.0   # MID
        elif progress < 0.99:
            return 5.0   # LATE
        else:
            return 3.0   # FINAL

    
    def validate_recovery_entry(self, 
                                oracle_confidence: float,
                                rsi_value: float,
                                macd_aligned: bool,
                                current_recovery_trades: int) -> tuple[bool, str]:
        """
        Validate if a trade qualifies for recovery execution.
        
        Ultra-conservative filters - ALL must pass.
        
        Returns:
            (allowed, reason)
        """
        if self.state != RecoveryState.RECOVERY:
            return False, "Not in recovery mode"
        
        # Check 1: Oracle confidence
        if oracle_confidence < self.min_oracle_confidence:
            return False, f"Oracle confidence {oracle_confidence:.2f} < {self.min_oracle_confidence:.2f}"
        
        # Check 2: RSI safe zone
        rsi_min, rsi_max = self.min_rsi_safe_zone
        if not (rsi_min <= rsi_value <= rsi_max):
            return False, f"RSI {rsi_value:.1f} outside safe zone [{rsi_min}, {rsi_max}]"
        
        # Check 3: MACD alignment
        if not macd_aligned:
            return False, "MACD not aligned with signal"
        
        # Check 4: Concurrent trade limit
        if current_recovery_trades >= self.max_concurrent_recovery:
            return False, f"Max concurrent recovery trades ({self.max_concurrent_recovery}) reached"
        
        return True, "RECOVERY_APPROVED"
    
    def calculate_recovery_lot(self, 
                              account_info: Dict,
                              atr_value: float = None) -> float:
        """
        Calculate lot size for recovery trade.
        
        Always returns micro lot (0.01) for safety.
        """
        return self.max_recovery_lot
    
    def track_recovery_trade_result(self, 
                                    trade_id: int,
                                    profit: float,
                                    was_successful: bool) -> None:
        """
        Track recovery trade outcome and update debt.
        
        Args:
            trade_id: Trade ticket/ID
            profit: Profit/loss from trade ($)
            was_successful: Whether trade hit TP (True) or SL (False)
        """
        if self.state != RecoveryState.RECOVERY:
            return
        
        # Update metrics
        self.metrics.recovery_trades += 1
        if was_successful:
            self.metrics.successful_trades += 1
        else:
            self.metrics.failed_trades += 1
        
        # Add to recovery trade history
        if trade_id not in self.recovery_trade_ids:
            self.recovery_trade_ids.append(trade_id)
        
        # Apply profit to debt (even if negative)
        self.metrics.debt_paid += profit
        
        # Log progress
        remaining = self.metrics.debt_remaining
        recovery_pct = self.metrics.recovery_rate
        
        logger.info(f"💰 [RECOVERY] Trade #{self.metrics.recovery_trades} Result: "
                   f"${profit:+.2f} | Debt: ${remaining:.2f} remaining "
                   f"({recovery_pct:.1f}% recovered)")
        
        # Check if debt fully paid
        if remaining <= 0:
            self._complete_recovery()
    
    def _complete_recovery(self) -> None:
        """Mark recovery as completed"""
        self.state = RecoveryState.COMPLETED
        self.metrics.completed_at = datetime.now()
        
        duration = (self.metrics.completed_at - self.metrics.started_at).total_seconds() / 60.0
        
        logger.critical(f"✅ [RECOVERY] DEBT FULLY PAID!")
        logger.critical(f"   Target: ${self.metrics.debt_target:.2f}")
        logger.critical(f"   Recovered: ${self.metrics.debt_paid:.2f}")
        logger.critical(f"   Recovery Trades: {self.metrics.recovery_trades}")
        logger.critical(f"   Win Rate: {self.metrics.win_rate:.1f}%")
        logger.critical(f"   Duration: {duration:.1f} minutes")
        logger.critical(f"   Ready to close frozen positions at breakeven")
    
    def should_close_frozen_positions(self) -> bool:
        """Check if frozen positions should be closed"""
        return self.state == RecoveryState.COMPLETED
    
    def get_frozen_position_ids(self) -> List[int]:
        """Get list of frozen position IDs"""
        return self.frozen_position_ids.copy()
    
    def get_recovery_metrics(self) -> Dict[str, Any]:
        """Get current recovery metrics"""
        return {
            'state': self.state.value,
            'debt_target': self.metrics.debt_target,
            'debt_paid': self.metrics.debt_paid,
            'debt_remaining': self.metrics.debt_remaining,
            'recovery_rate': self.metrics.recovery_rate,
            'trades_executed': self.metrics.recovery_trades,
            'win_rate': self.metrics.win_rate,
            'is_active': self.state == RecoveryState.RECOVERY,
            'is_completed': self.state == RecoveryState.COMPLETED
        }
    
    def reset(self) -> None:
        """Reset recovery engine to normal state"""
        logger.info(f"[RECOVERY] Resetting engine (was in {self.state.value} state)")
        self.state = RecoveryState.NORMAL
        self.metrics = RecoveryMetrics()
        self.frozen_position_ids.clear()
        self.recovery_trade_ids.clear()
    
    def is_recovery_active(self) -> bool:
        """Check if recovery mode is active"""
        return self.state == RecoveryState.RECOVERY
    
    def is_recovery_completed(self) -> bool:
        """Check if recovery is completed"""
        return self.state == RecoveryState.COMPLETED
