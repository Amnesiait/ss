import logging
import numpy as np
import time
import os
from typing import Dict, List

logger = logging.getLogger("ContrastiveFusion")

class ContrastiveFusion:
    """
    Multi-Modal Signal Validator with Intelligence Fixes.
    Uses Contrastive Learning principles to align disparate data sources:
    1. Tick Velocity (Micro-structure)
    2. Candle Patterns (Price Action)
    3. Order Book Imbalance (Liquidity)
    
    FIXES APPLIED:
    [FIX 1] Dead signal detection - auto-disables broken Order Book
    [FIX 2] Dynamic weight redistribution when signals fail
    [FIX 3] Regime-aware coherence thresholds (CHAOS vs RANGE vs TREND)
    [FIX 4] Position sizing based on coherence confidence
    """
    def __init__(self):
        # [FIX 1] Detect if Order Book is dead (always returns None/0)
        # If MT5 market depth not working, disable it from consensus
        self.order_book_dead = False
        self.dead_signal_count = 0
        self.max_dead_samples = 50  # Check first 50 signals
        
        # [FIX 2] Dynamic weights - if Order Book is dead, redistribute
        self.weights = {
            "tick_velocity": 0.5,
            "candle_pattern": 0.5,
            "order_book": 0.0  # Start disabled until we verify MT5 provides data
        }
        
        # Original weights (for when Order Book works)
        self.weights_with_obi = {
            "tick_velocity": 0.4,
            "candle_pattern": 0.4,
            "order_book": 0.2
        }

        # Allow silencing of conflict logs via env (AETHER_FUSION_LOG=0)
        self._log_enabled = str(os.getenv("AETHER_FUSION_LOG", "1")).strip().lower() in (
            "1",
            "true",
            "yes",
            "on",
        )

        # [FIX 3] Regime-aware thresholds (will be set by oracle)
        self.current_regime = "UNKNOWN"
        self.regime_thresholds = {
            "CHAOS": 0.25,    # Very lenient in volatile markets
            "RANGE": 0.45,    # Moderate in ranging markets
            "TREND": 0.60,    # Strict in trending markets
        }
        
        # [FIX 4] Store last coherence for position sizing
        self.last_coherence = 0.5

        # Log-throttling for noisy conflict warnings (behavior unchanged; only reduces spam)
        self._conflict_log_interval_s = 5.0
        self._last_conflict_log_ts = 0.0
        self._conflict_suppressed = 0

    def set_regime(self, regime: str):
        """[FIX 3] Update current regime for threshold awareness."""
        self.current_regime = regime if regime in self.regime_thresholds else "UNKNOWN"

    def _detect_dead_order_book(self, obi_signal: float):
        """[FIX 1] Detect if Order Book signal is consistently dead."""
        if not self.order_book_dead and self.dead_signal_count < self.max_dead_samples:
            if obi_signal is None or abs(obi_signal) < 1e-6:
                self.dead_signal_count += 1
                if self.dead_signal_count >= self.max_dead_samples:
                    logger.warning(
                        f"[FUSION] Order Book signal detected as DEAD (50+ null samples). "
                        f"MT5 market depth unavailable. Disabling from consensus."
                    )
                    self.order_book_dead = True
                    self.weights = {"tick_velocity": 0.5, "candle_pattern": 0.5, "order_book": 0.0}
            else:
                # Good signal received - enable OBI
                if self.dead_signal_count > 0:
                    logger.info(f"[FUSION] Order Book signal ALIVE. Re-enabling in consensus.")
                    self.dead_signal_count = 0
                    self.weights = self.weights_with_obi

    def compute_coherence(self, signals: Dict[str, float]) -> float:
        """
        [FIX 1, 2] Calculates a coherence score (0.0 to 1.0) for signals with dead signal detection.
        
        Args:
            signals: Dict with keys 'tick_velocity', 'candle_pattern', 'order_book'.
                     Values should be normalized between -1 (Strong Sell) and 1 (Strong Buy).
        
        Returns:
            float: Coherence score. High score means all signals point in the same direction.
        """
        # [FIX 1] Detect dead Order Book
        obi = signals.get("order_book", 0.0)
        self._detect_dead_order_book(obi)
        
        # Extract vectors (exclude dead Order Book from consensus)
        if self.order_book_dead or self.weights["order_book"] == 0.0:
            # Only use the 2 reliable signals
            vec = np.array([
                signals.get("tick_velocity", 0.0),
                signals.get("candle_pattern", 0.0),
            ])
            active_weights = {"tick_velocity": 0.5, "candle_pattern": 0.5}
        else:
            vec = np.array([
                signals.get("tick_velocity", 0.0),
                signals.get("candle_pattern", 0.0),
                signals.get("order_book", 0.0)
            ])
            active_weights = self.weights
        
        # 1. Directional Agreement Check
        # If some are positive and some are negative, coherence drops
        signs = np.sign(vec)
        # Filter out zeros for sign check
        non_zero_signs = signs[signs != 0]
        
        if len(non_zero_signs) > 1 and not np.all(non_zero_signs == non_zero_signs[0]):
            # Conflict detected (e.g. Tick says Buy, Candles say Sell)
            # [FIX 2] Conflict penalty is 0.2 instead of 0.1 (less harsh)
            if self._log_enabled:
                now = time.monotonic()
                if now - self._last_conflict_log_ts >= self._conflict_log_interval_s:
                    if self._conflict_suppressed:
                        logger.debug(
                            f"[FUSION] Signal Conflict Detected (throttled): {self._conflict_suppressed} repeats suppressed"
                        )
                        self._conflict_suppressed = 0
                    logger.debug(f"[FUSION] Signal Conflict Detected: {signals}")
                    self._last_conflict_log_ts = now
                else:
                    self._conflict_suppressed += 1
            return 0.2  # Slightly less harsh than 0.1

        # 2. Magnitude Alignment (Weighted Average)
        # If direction is agreed, how strong is the consensus?
        weighted_sum = 0.0
        num_modalities = 2 if len(vec) == 2 else 3
        for i, key in enumerate(["tick_velocity", "candle_pattern"] if len(vec) == 2 else ["tick_velocity", "candle_pattern", "order_book"]):
            if i < len(vec):
                weighted_sum += abs(vec[i]) * active_weights.get(key, 0.0)

        # [FIX 4] Dynamic sizing using coherence (implemented in oracle.py)
        # Store coherence for position sizing
        self.last_coherence = weighted_sum
        
        # [OPTIMIZATION] Lone Wolf Logic (Frequency Boost)
        # If one signal is Moderately Strong (>0.50) and there are NO conflicts,
        # allow the trade to proceed. Threshold reduced from 0.60 to 0.50.
        max_signal = np.max(np.abs(vec)) if len(vec) > 0 else 0.0
        if max_signal > 0.50:  # Reduced from 0.60
             # We have a decent signal. Boost coherence.
             if weighted_sum < 0.70:  # Reduced from 0.85
                 logger.debug(f"[FUSION] Lone Wolf (Frequency) Accepted! Max({max_signal:.2f}) > 0.50. Boosting coherence to 0.70.")
                 return 0.70
        
        return min(1.0, weighted_sum)

    def validate_signal(self, raw_signal: float, coherence: float, regime: str = "UNKNOWN") -> float:
        """
        [FIX 3] Adjusts the raw signal confidence based on coherence AND regime.
        
        Args:
            raw_signal: Base AI signal strength (-1 to 1)
            coherence: Signal coherence score (0 to 1)
            regime: Market regime for threshold awareness
        
        Returns:
            Final confidence score (0 to 1)
        """
        # [FIX 3] Get regime-aware threshold
        threshold = self.regime_thresholds.get(regime, 0.40)
        
        if coherence < threshold:
            return 0.0  # Reject signal below regime threshold
        
        # Boost high coherence signals
        boost = 1.2 if coherence > 0.8 else 1.0
        return min(1.0, raw_signal * boost)
