import time
from collections import deque
from typing import Tuple, Dict, Any
import numpy as np

class TickPressureAnalyzer:
    """
    "Holographic" Market View: Simulates Order Flow (Level 2) using Tick Velocity.
    Detects Institutional Aggression vs Retail Noise.
    
    ENHANCEMENT 2: Added Order Flow Imbalance Analysis (Jan 4, 2026)
    """
    def __init__(self, window_seconds=5):
        self.window_seconds = window_seconds
        self.ticks = deque() # Stores (price, time)
        
        # ENHANCEMENT 2: Order Flow Imbalance Tracking
        self.buy_volume_buffer = deque(maxlen=100)
        self.sell_volume_buffer = deque(maxlen=100)
        self.max_buffer_size = 100
        
    def add_tick(self, tick):
        """
        Add a new tick to the analyzer.
        Args:
            tick: Dictionary containing 'bid', 'ask', 'time'
        """
        if not tick:
            return
            
        # Use Bid price for pressure analysis.
        # IMPORTANT: Use local wall-clock time for timing/velocity.
        # MT5 tick timestamps are often coarse (seconds) which can make duration ~0
        # and artificially saturate velocity/pressure.
        price = tick.get('bid', 0.0)
        current_time = time.time()
        
        if price > 0:
            self.ticks.append((price, current_time))
            self._cleanup(current_time)
        
    def _cleanup(self, current_time):
        while self.ticks and (current_time - self.ticks[0][1] > self.window_seconds):
            self.ticks.popleft()
            
    def get_pressure_metrics(self, point_value=0.01):
        """
        Calculates Tick Pressure (Aggression).
        Returns: Dictionary with pressure metrics
        """
        if len(self.ticks) < 5:
            return {
                'pressure_score': 0.0,
                'intensity': 'LOW',
                'dominance': 'NEUTRAL',
                'state': 'INSUFFICIENT_DATA',
                'velocity': 0.0
            }
            
        start_price = self.ticks[0][0]
        end_price = self.ticks[-1][0]
        price_change = end_price - start_price
        
        tick_count = len(self.ticks)
        duration = self.ticks[-1][1] - self.ticks[0][1]
        if duration <= 0: duration = 0.001
        
        # Velocity = Ticks per Second (Speed of orders)
        velocity = tick_count / duration
        
        # Normalized Price Change (in Points)
        price_delta_points = price_change / point_value
        
        # Pressure = Price Delta * Velocity
        # Example: +10 points * 5 ticks/sec = +50 (Strong Buy)
        # Example: +1 points * 50 ticks/sec = +50 (Massive Absorption/Buy)
        pressure = price_delta_points * velocity
        
        state = "NEUTRAL"
        intensity = "NORMAL"
        dominance = "NEUTRAL"
        
        # Thresholds (Tuned for Gold)
        if pressure > 50.0: 
            state = "INSTITUTIONAL_BUY"
            intensity = "HIGH"
            dominance = "BUY"
        elif pressure > 15.0: 
            state = "STRONG_BUY"
            intensity = "MEDIUM"
            dominance = "BUY"
        elif pressure < -50.0: 
            state = "INSTITUTIONAL_SELL"
            intensity = "HIGH"
            dominance = "SELL"
        elif pressure < -15.0: 
            state = "STRONG_SELL"
            intensity = "MEDIUM"
            dominance = "SELL"
        elif velocity > 10.0 and abs(price_delta_points) < 2.0: 
            state = "ABSORPTION_FIGHT" # High volume, no movement (Trap)
            intensity = "HIGH"
            dominance = "NEUTRAL"
        elif velocity < 1.0:
            state = "LOW_LIQUIDITY"
            intensity = "LOW"
            
        return {
            'pressure_score': pressure,
            'intensity': intensity,
            'dominance': dominance,
            'state': state,
            'velocity': velocity
        }
    
    # ============================================================================
    # ENHANCEMENT 2: Order Flow Imbalance Analysis
    # Added: January 4, 2026
    # Purpose: Detect buy vs sell aggressor volume for better entry timing
    # ============================================================================
    
    def analyze_order_flow(self, tick):
        """
        Analyze buy vs sell volume imbalance from tick data.
        
        Detects aggressor side (who crossed the spread) and tracks volume imbalance.
        
        Args:
            tick: Dictionary with 'last', 'bid', 'ask', 'volume' keys
            
        Returns:
            Dictionary with:
            - order_flow_imbalance: -1 to 1 (negative = sell pressure, positive = buy pressure)
            - buy_pressure: Ratio of buy volume (0-1)
            - sell_pressure: Ratio of sell volume (0-1)
        """
        if not tick:
            return {
                'order_flow_imbalance': 0.0,
                'buy_pressure': 0.5,
                'sell_pressure': 0.5
            }
        
        try:
            last_price = tick.get('last', tick.get('bid', 0))
            bid = tick.get('bid', 0)
            ask = tick.get('ask', 0)
            volume = tick.get('volume', 1)
            
            # [FIX] Enhanced Quote-Driven Aggressor Logic
            # Standard FX/CFD feeds often send last=0 (Quote Updates). 
            # We must infer direction from Mid-Price Delta.
            
            mid_price = (bid + ask) / 2
            
            # Helper to store previous mid price
            if not hasattr(self, '_prev_mid'):
                self._prev_mid = mid_price
                
            is_quote_update = abs(last_price) < 1e-9 or abs(last_price - bid) < 1e-9 or abs(last_price - ask) < 1e-9
            
            if not is_quote_update:
                # Standard Trade Tick Logic (Futures/Stocks)
                if last_price >= ask:
                     self.buy_volume_buffer.append(volume)
                elif last_price <= bid:
                     self.sell_volume_buffer.append(volume)
                else:
                     self.buy_volume_buffer.append(volume / 2)
                     self.sell_volume_buffer.append(volume / 2)
            else:
                # [Inferred] Quote Update Logic
                # If Mid-Price moved UP -> Buying Pressure
                # If Mid-Price moved DOWN -> Selling Pressure
                if mid_price > self._prev_mid:
                    self.buy_volume_buffer.append(volume)
                elif mid_price < self._prev_mid:
                    self.sell_volume_buffer.append(volume)
                else:
                    # Neutral (Spread change only or steady)
                    self.buy_volume_buffer.append(volume / 2)
                    self.sell_volume_buffer.append(volume / 2)
            
            self._prev_mid = mid_price
            
            # Calculate imbalance from buffers
            buy_vol = sum(self.buy_volume_buffer) if self.buy_volume_buffer else 0
            sell_vol = sum(self.sell_volume_buffer) if self.sell_volume_buffer else 0
            total_vol = buy_vol + sell_vol
            
            if total_vol > 0:
                # Imbalance: -1 (all sell) to +1 (all buy)
                imbalance = (buy_vol - sell_vol) / total_vol
                buy_pressure = buy_vol / total_vol
                sell_pressure = sell_vol / total_vol
            else:
                imbalance = 0.0
                buy_pressure = 0.5
                sell_pressure = 0.5
            
            return {
                'order_flow_imbalance': float(imbalance),
                'buy_pressure': float(buy_pressure),
                'sell_pressure': float(sell_pressure),
                'buy_volume': float(buy_vol),
                'sell_volume': float(sell_vol)
            }
            
        except Exception as e:
            # On error, return neutral
            return {
                'order_flow_imbalance': 0.0,
                'buy_pressure': 0.5,
                'sell_pressure': 0.5
            }
    
    # ============================================================================
    # ENHANCEMENT 3: The Physicist & The Chemist (Unified Field Theory)
    # Added: January 8, 2026
    # Purpose: Deterministic prediction using Hydro-Thermodynamics
    # ============================================================================

    def calculate_vpin(self) -> float:
        """
        [THE CHEMIST] Calculate Volume-Synchronized Probability of Informed Trading.
        Approximation: VPIN = |V_buy - V_sell| / Total_Volume
        
        Returns:
            VPIN score (0.0 to 1.0). >0.4 indicates Toxic/Informed Flow.
        """
        buy_vol = sum(self.buy_volume_buffer) if self.buy_volume_buffer else 0
        sell_vol = sum(self.sell_volume_buffer) if self.sell_volume_buffer else 0
        total_vol = buy_vol + sell_vol
        
        if total_vol <= 0:
            return 0.0
            
        # Require minimum samples to be statistically significant
        # If we have very few trades (e.g. < 15), VPIN is noisy (likely 1.0).
        buy_samples = len(self.buy_volume_buffer)
        sell_samples = len(self.sell_volume_buffer)
        
        # Note: Buffers are appended independently. total trades ~= sum of lengths / ? 
        # Actually neutral trades append to BOTH. 
        # A safer proxy for "Total Trades Analyzed" is max(len(buy), len(sell)) or we track count separately.
        # But since we append to at least one, (buy_samples + sell_samples) is at least total trades.
        # Let's simple check if we have enough volume data points.
        
        if (buy_samples + sell_samples) < 15:
            return 0.0
            
        return abs(buy_vol - sell_vol) / total_vol

    def calculate_reynolds_number(self, spread_points: float, point_value: float = 0.01) -> float:
        """
        [THE PHYSICIST] Calculate Reynolds Number (Re) for Phase Transition detection.
        Re = (Volume * Volatility) / Viscosity(Spread)
        
        Args:
            spread_points: Current spread in points
            point_value: value of a point
            
        Returns:
            Re score. High Re (>1000) = Turbulent (Breakout). Low Re = Laminar (Range).
        """
        if spread_points <= 0 or not self.ticks:
            return 0.0
            
        # 1. Characteristic Volume (Velocity)
        # Using ticks/sec as proxy for flow velocity u
        duration = self.ticks[-1][1] - self.ticks[0][1]
        if duration <= 0: duration = 0.001
        velocity = len(self.ticks) / duration
        
        # 2. Characteristic Length (Volatility/Turbulence)
        # StdDev of prices in window
        prices = [p[0] for p in self.ticks]
        if len(prices) > 2:
            import numpy as np
            volatility = np.std(prices) / point_value
        else:
            volatility = 0.0
            
        # 3. Viscosity (Spread)
        viscosity = spread_points
        
        # Re = (Velocity * Volatility) / Viscosity
        # Scaling factor 100 to make numbers readable (e.g., 0-5000)
        re = (velocity * volatility * 100) / viscosity
        
        return float(re)

    def calculate_navier_stokes_pressure(self, order_flow_imbalance: float, velocity: float) -> float:
        """
        [THE PHYSICIST] Calculate Net Force (Pressure Gradient).
        F = Mass * Acceleration
        Approximation: Force = Imbalance * Velocity
        """
        return order_flow_imbalance * velocity

    def calculate_reaction_rate(self) -> float:
        """
        [THE CHEMIST] Calculate Liquidity Consumption Rate.
        Reaction Rate = Trade Frequency / Time
        (Simple proxy: Ticks per second, which is roughly velocity)
        """
        if len(self.ticks) < 2: 
            return 0.0
            
        duration = self.ticks[-1][1] - self.ticks[0][1]
        if duration <= 0: return 0.0
        
        return len(self.ticks) / duration

    def get_combined_analysis(self, tick, point_value=0.01):
        """
        Get all Physics & Chemistry metrics in one call.
        """
        pressure = self.get_pressure_metrics(point_value)
        order_flow = self.analyze_order_flow(tick)
        
        # Extract needed data for Physics
        ask = tick.get('ask', 0)
        bid = tick.get('bid', 0)
        spread = (ask - bid) if (ask > 0 and bid > 0) else 0.0001
        spread_points = spread / point_value
        
        # [THE PHYSICIST]
        re = self.calculate_reynolds_number(spread_points, point_value)
        ns_pressure = self.calculate_navier_stokes_pressure(
            order_flow['order_flow_imbalance'], 
            pressure['velocity']
        )
        
        # [THE CHEMIST]
        vpin = self.calculate_vpin()
        reaction = self.calculate_reaction_rate()
        
        combined = {
            **pressure,
            **order_flow,
            'physics': {
                'reynolds_number': re,
                'navier_stokes_force': ns_pressure,
                'regime': 'TURBULENT' if re > 500 else 'LAMINAR' # Threshold to be tuned
            },
            'chemistry': {
                'vpin': vpin,
                'reaction_rate': reaction,
                'is_toxic': vpin > 0.4
            }
        }
        return combined

    # ============================================================================
    # PHASE 3: THE GUARD (SIGMA CRASH DETECTION)
    # Added: February 2026
    # Purpose: Detect 4-Sigma Events (Flash Crashes) instantly
    # ============================================================================

    def calculate_sigma(self, current_price: float) -> Tuple[float, str]:
        """
        Calculate Z-Score of the current price against the recent window.
        Z = (Price - Mean) / StdDev
        
        Returns: (Z-Score, Status)
        """
        if len(self.ticks) < 20: # Need minimum sample size
            return 0.0, "INSUFFICIENT_DATA"
            
        prices = [p[0] for p in self.ticks]
        
        mean_price = np.mean(prices)
        std_dev = np.std(prices)
        
        if std_dev == 0:
            return 0.0, "STABLE"
            
        z_score = (current_price - mean_price) / std_dev
        
        status = "NORMAL"
        if abs(z_score) > 4.0:
            status = "CRASH_DETECTED" if z_score < 0 else "VELOCITY_SPIKE"
            
        return z_score, status

    def check_crash_status(self, tick) -> Tuple[bool, str]:
        """
        [THE GUARD] Main Check Loop.
        1. Check Spread (Liquidity Vacuum)
        2. Check Z-Score (Sigma Event)
        
        Returns: (is_crash, reason)
        """
        if not tick: return False, "NO_DATA"
        
        # 1. Liquidity Vacuum Check
        ask = tick.get('ask', 0)
        bid = tick.get('bid', 0)
        spread = ask - bid
        # Hard-coded safety limit for Gold (assuming 0.35 is user's limit)
        # NOTE: Future enhancement - parameterize tick pressure thresholds
        # Tracked for v8.0 configuration improvements

        if spread > 0.50: # 50 cents on Gold
             return True, f"LIQUIDITY_VACUUM: Spread {spread:.2f} > 0.50"
             
        # 2. Sigma Event Check
        z_score, status = self.calculate_sigma(bid)
        if abs(z_score) > 4.0:
            return True, f"SIGMA_EVENT: Z-Score {z_score:.2f} (Status: {status})"
            
        return False, "SAFE"
