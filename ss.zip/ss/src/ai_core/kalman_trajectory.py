
import logging
from dataclasses import dataclass

logger = logging.getLogger("TheSniper")

@dataclass
class Trajectory:
    __slots__ = ['price', 'estimate', 'deviation', 'signal', 'momentum']
    price: float
    estimate: float
    deviation: float
    signal: str # "BUY", "SELL", "NEUTRAL"
    momentum: float # Slope of the estimate

class KalmanSniper:
    """
    [THE SNIPER]
    Mathematical Price Trajectory Predictor using a 1D Kalman Filter.
    Replaces need for Level 2 Data by inferring 'True Price' from 'Noisy Price'.
    """
    def __init__(self, gain: float = 0.8):
        self.gain = gain # K-Factor (0.8 = Fast/Scalping, 0.1 = Trend)
        self.estimate = None
        self.error_est = 1.0
        self.error_meas = 1.0 # Measurement noise (assumed constant)
        self.last_price = 0.0

    def update(self, current_price: float) -> Trajectory:
        """
        Update the filter with a new price tick.
        
        [KALMAN GAIN EXPLAINED]
        The Gain (K = 0.8) determines the 'Trust Factor':
        - High K (0.8): Trust Measurement (Current Price). Good for Scalping (Fast Reaction).
        - Low K (0.1): Trust Estimate (Prediction). Good for Trend Following (Noise Smoothing).
        
        Formula: Estimate = OldEstimate + Gain * (Measurement - OldEstimate)
        """
        if self.estimate is None:
            self.estimate = current_price
            self.last_price = current_price
            return Trajectory(current_price, current_price, 0.0, "NEUTRAL", 0.0)

        # 1. Prediction (Simple model: Price stays same)
        pred_est = self.estimate
        
        # 2. Update (Correction)
        # K = ErrorEst / (ErrorEst + ErrorMeas) -- Simplified to fixed Gain for speed
        K = self.gain 
        
        self.estimate = pred_est + K * (current_price - pred_est)
        
        # Calculate Deviation (Sniper Signal)
        # If Price is significantly ABOVE estimate, it's an UP spike (Reversion Risk or Breakout?)
        # For Scalping: We follow the TRAJECTORY (Estimate), not the noise.
        
        deviation = current_price - self.estimate
        momentum = self.estimate - (self.last_price if self.last_price else self.estimate)
        
        # Generation Signal based on user logic:
        # "Deviation > 0.5 -> BUY" (User's specific request)
        # Interpreting User Logic:
        # If Price pulls away from Estimate, it's a "Breakout".
        signal = "NEUTRAL"
        if deviation > 0.5:
            signal = "BUY"
        elif deviation < -0.5:
            signal = "SELL"
            
        self.last_price = self.estimate # Track previous estimate for momentum
        
        return Trajectory(
            price=current_price,
            estimate=self.estimate,
            deviation=deviation,
            signal=signal,
            momentum=momentum
        )

    def get_reversal_signal(self, current_price: float) -> str:
        """
        Used for 'Smart Unwind'.
        Detects when the momentum flips against the current trend.
        """
        t = self.update(current_price)
        if t.momentum > 0 and current_price < t.estimate:
             return "REVERSAL_DOWN"
        if t.momentum < 0 and current_price > t.estimate:
             return "REVERSAL_UP"
        return "CONTINUATION"
