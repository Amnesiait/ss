"""
Kelly Criterion - Mathematical Position Sizing

Implements the Kelly Criterion for optimal position sizing based on win rate and profit factor.
Uses fractional Kelly (25%) to prevent over-betting and includes safety caps based on drawdown.

Mathematical Foundation:
    f* = (p × b - q) / b
    
    Where:
    f* = Fraction of capital to risk (Kelly fraction)
    p = Probability of win (win rate)
    b = Ratio of win to loss (profit factor)
    q = Probability of loss (1 - p)

Author: Recovery Engine Team
Date: 2026-02-04
"""

import logging
from collections import deque
from typing import Optional, Tuple
from datetime import datetime

logger = logging.getLogger("KellyCriterion")


class KellyCriterion:
    """
    Kelly Criterion position sizing calculator.
    
    Tracks trade history and calculates optimal position multipliers
    based on historical win rate and profit factor.
    """
    
    def __init__(self, history_size: int = 100, min_trades: int = 20):
        """
        Initialize Kelly Criterion calculator.
        
        Args:
            history_size: Maximum number of trades to track
            min_trades: Minimum trades needed before using Kelly (else fallback)
        """
        self.trade_history = deque(maxlen=history_size)
        self.min_trades = min_trades
        
        # Statistics
        self.total_trades = 0
        self.winning_trades = 0
        self.losing_trades = 0
        
        logger.info(f"[KELLY] Initialized with {history_size} trade history, {min_trades} min trades")
    
    def track_trade(self, profit_usd: float) -> None:
        """
        Record a completed trade result.
        
        Args:
            profit_usd: Trade profit in USD (positive = win, negative = loss)
        """
        self.trade_history.append(profit_usd)
        self.total_trades += 1
        
        if profit_usd > 0:
            self.winning_trades += 1
        else:
            self.losing_trades += 1
        
        logger.debug(f"[KELLY] Trade recorded: ${profit_usd:.2f} | Total: {self.total_trades} | Win Rate: {self.get_win_rate():.1%}")
    
    def has_sufficient_history(self) -> bool:
        """
        Check if we have enough trade history to use Kelly.
        
        Returns:
            True if sufficient history, False otherwise
        """
        return len(self.trade_history) >= self.min_trades
    
    def get_win_rate(self) -> float:
        """
        Calculate current win rate.
        
        Returns:
            Win rate as decimal (0.0 to 1.0)
        """
        if len(self.trade_history) == 0:
            return 0.5  # Default 50%
        
        wins = [t for t in self.trade_history if t > 0]
        return len(wins) / len(self.trade_history)
    
    def get_profit_factor(self) -> float:
        """
        Calculate profit factor (avg win / avg loss).
        
        Returns:
            Profit factor (>1.0 = profitable system)
        """
        wins = [t for t in self.trade_history if t > 0]
        losses = [abs(t) for t in self.trade_history if t < 0]
        
        if not wins or not losses:
            return 1.0  # Neutral
        
        avg_win = sum(wins) / len(wins)
        avg_loss = sum(losses) / len(losses)
        
        return avg_win / avg_loss if avg_loss > 0 else 1.0
    
    def calculate_kelly_fraction(self) -> float:
        """
        Calculate the Kelly fraction (optimal % of capital to risk).
        
        Returns:
            Kelly fraction (0.0 to 1.0)
        """
        if not self.has_sufficient_history():
            return 0.01  # Conservative default (1%)
        
        win_rate = self.get_win_rate()
        profit_factor = self.get_profit_factor()
        
        # [SAFETY] Protect against division by zero if profit_factor = 0
        if profit_factor == 0:
            return 0.0  # No edge, don't risk capital
        
        # Kelly Formula: f* = (p * b - q) / b
        # Where p = win_rate, b = profit_factor, q = (1 - win_rate)
        kelly_f = (win_rate * profit_factor - (1 - win_rate)) / profit_factor
        
        # Clamp to valid range [0, 1]
        kelly_f = max(0.0, min(kelly_f, 1.0))
        
        return kelly_f
    
    def get_optimal_multiplier(
        self, 
        current_drawdown: float = 0.0, 
        confidence: float = 0.5
    ) -> float:
        """
        Calculate optimal lot size multiplier using Kelly Criterion.
        
        Args:
            current_drawdown: Current account drawdown (0.0 to 1.0)
            confidence: Oracle confidence (0.0 to 1.0)
        
        Returns:
            Multiplier for lot sizing (e.g., 1.5, 2.0, 2.5)
        """
        if not self.has_sufficient_history():
            # Not enough data, use conservative default
            return 1.5
        
        # Calculate full Kelly fraction
        full_kelly = self.calculate_kelly_fraction()
        
        # Use fractional Kelly (25%) to reduce volatility
        # Rationale: Full Kelly can be too aggressive; fractional Kelly proven safer
        fractional_kelly = full_kelly * 0.25
        
        # Convert fraction to multiplier
        # 0.01 (1%) = 1.0x multiplier
        # 0.05 (5%) = 5.0x multiplier
        # We scale: fraction * 100 = multiplier
        base_multiplier = fractional_kelly * 100.0
        
        # Boost for high confidence trades
        if confidence > 0.8:
            base_multiplier *= 1.1  # 10% boost
        elif confidence < 0.4:
            base_multiplier *= 0.9  # 10% reduction
        
        # SAFETY CAPS based on drawdown
        if current_drawdown > 0.25:
            # CRITICAL: 25%+ drawdown, enforce FLAT STAKE
            max_multiplier = 1.0
            logger.warning(f"[KELLY] CRITICAL DD {current_drawdown:.1%} - FLAT STAKE enforced")
        elif current_drawdown > 0.20:
            # SURVIVAL: 20%+ drawdown, cap at 1.0x
            max_multiplier = 1.0
        elif current_drawdown > 0.15:
            # Tier 4 territory: cap at 1.5x
            max_multiplier = 1.5
        elif current_drawdown > 0.10:
            # Tier 3: cap at 2.0x
            max_multiplier = 2.0
        elif current_drawdown > 0.05:
            # Tier 2: cap at 2.5x
            max_multiplier = 2.5
        else:
            # Tier 1: normal operation, cap at 3.0x for safety
            max_multiplier = 3.0
        
        # Apply cap
        final_multiplier = min(base_multiplier, max_multiplier)
        
        # Enforce minimum (never go below 0.5x)
        final_multiplier = max(final_multiplier, 0.5)
        
        # Round to 1 decimal place
        final_multiplier = round(final_multiplier, 1)
        
        logger.info(
            f"[KELLY] Multiplier: {final_multiplier:.1f}x | "
            f"WinRate: {self.get_win_rate():.1%} | "
            f"PF: {self.get_profit_factor():.2f} | "
            f"Kelly: {full_kelly:.3f} | "
            f"DD: {current_drawdown:.1%}"
        )
        
        return final_multiplier
    
    def get_current_tier(self, drawdown: float) -> int:
        """
        Determine current risk tier based on drawdown.
        
        Args:
            drawdown: Current drawdown percentage (0.0 to 1.0)
        
        Returns:
            Tier number (1-4)
        """
        if drawdown < 0.05:
            return 1
        elif drawdown < 0.10:
            return 2
        elif drawdown < 0.20:
            return 3
        else:
            return 4
    
    def get_statistics(self) -> dict:
        """
        Get current Kelly statistics.
        
        Returns:
            Dictionary of statistics
        """
        return {
            'total_trades': self.total_trades,
            'winning_trades': self.winning_trades,
            'losing_trades': self.losing_trades,
            'win_rate': self.get_win_rate(),
            'profit_factor': self.get_profit_factor(),
            'kelly_fraction': self.calculate_kelly_fraction(),
            'has_sufficient_history': self.has_sufficient_history(),
            'history_size': len(self.trade_history)
        }
