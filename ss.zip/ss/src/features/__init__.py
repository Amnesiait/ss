"""
AETHER Features Module

Provides feature engineering and analysis modules for trading.

Author: AETHER Development Team  
Version: 1.0.0
"""

__all__ = ['volume_profile', 'market_features']
