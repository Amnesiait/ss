"""
Volume Profile Analysis Module

Implements world-class Volume Profile (VPVR) analysis for identifying:
- POC (Point of Control): Price level with highest traded volume
- VAH/VAL (Value Area High/Low): 70% volume distribution boundaries
- HVN (High Volume Nodes): Support/Resistance levels
- LVN (Low Volume Nodes): Breakout zones with minimal resistance

Optimized for M1 scalping with smart caching and ATR-based bin sizing.

Author: AETHER Development Team
Version: 1.0.0
"""

import logging
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from threading import Lock

logger = logging.getLogger("VolumeProfile")


@dataclass
class VolumeProfileResult:
    """
    Volume Profile calculation result.
    """
    poc: float  # Point of Control (price with max volume)
    vah: float  # Value Area High (upper 70% boundary)
    val: float  # Value Area Low (lower 70% boundary)
    hvn_levels: List[float]  # High Volume Nodes (support/resistance)
    lvn_levels: List[float]  # Low Volume Nodes (breakout zones)
    volume_distribution: Dict[float, float]  # {price: volume} histogram
    total_volume: float  # Total volume in the profile
    valid: bool  # Whether profile is valid (sufficient data)
    
    def __repr__(self):
        return (f"VolumeProfile(POC={self.poc:.5f}, "
                f"VAH={self.vah:.5f}, VAL={self.val:.5f}, "
                f"HVN={len(self.hvn_levels)}, LVN={len(self.lvn_levels)})")


class VolumeProfile:
    """
    Advanced Volume Profile calculator with intelligent features.
    """
    
    def __init__(self, lookback_bars: int = 100, value_area_pct: float = 0.70):
        """
        Initialize Volume Profile calculator.
        
        Args:
            lookback_bars: Number of candles to analyze (default 100 for M1 = ~1.5 hours)
            value_area_pct: Percentage for Value Area calculation (default 70%)
        """
        self.lookback_bars = lookback_bars
        self.value_area_pct = value_area_pct
        
        # Cache to avoid recalculation (invalidate on new candle)
        self._cache: Optional[VolumeProfileResult] = None
        self._cache_key: Optional[Tuple] = None  # (last_candle_time, symbol)
        self._cache_lock = Lock()
        
        logger.info(f"[VOLUME_PROFILE] Initialized (lookback={lookback_bars}, VA={value_area_pct:.0%})")
    
    def calculate(self, candles: List[Dict], atr: float = None, 
                 num_bins: Optional[int] = None) -> VolumeProfileResult:
        """
        Calculate Volume Profile from candle data.
        
        Args:
            candles: List of candle dicts with OHLCV data
            atr: Current ATR for adaptive bin sizing (optional)
            num_bins: Override number of price bins (default: auto from ATR)
        
        Returns:
            VolumeProfileResult with POC, VAH, VAL, and volume nodes
        """
        try:
            # Validate input
            if not candles or len(candles) < 10:
                return self._empty_profile("Insufficient candles")
            
            # Use last N candles
            candles = candles[-self.lookback_bars:]
            
            # Check cache (based on last candle time)
            cache_key = (candles[-1].get('time', 0), candles[-1].get('symbol', ''))
            with self._cache_lock:
                if self._cache is not None and self._cache_key == cache_key:
                    return self._cache
            
            # Extract price and volume data
            highs = np.array([float(c['high']) for c in candles])
            lows = np.array([float(c['low']) for c in candles])
            closes = np.array([float(c['close']) for c in candles])
            volumes = np.array([float(c.get('tick_volume', 1)) for c in candles])
            
            # Calculate price range
            price_min = float(np.min(lows))
            price_max = float(np.max(highs))
            price_range = price_max - price_min
            
            if price_range <= 0:
                return self._empty_profile("Zero price range")
            
            # Adaptive bin sizing based on ATR
            if num_bins is None:
                if atr and atr > 0:
                    # Use ATR to set bin size: each bin = ATR / 4
                    bin_size = atr / 4.0
                    num_bins = max(20, min(100, int(price_range / bin_size)))
                else:
                    # Default: ~50 bins for good resolution
                    num_bins = 50
            
            # Create price bins (histogram)
            bin_edges = np.linspace(price_min, price_max, num_bins + 1)
            bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0
            bin_volumes = np.zeros(num_bins)
            
            # Distribute volume across bins
            for i in range(len(candles)):
                # Use VWAP-like distribution: volume distributed between low and high
                candle_low = lows[i]
                candle_high = highs[i]
                candle_vol = volumes[i]
                
                # Find bins that overlap with this candle's range
                overlapping_bins = (bin_centers >= candle_low) & (bin_centers <= candle_high)
                num_overlapping = np.sum(overlapping_bins)
                
                if num_overlapping > 0:
                    # Distribute volume evenly across overlapping bins
                    bin_volumes[overlapping_bins] += candle_vol / num_overlapping
            
            # Find POC (Point of Control) - bin with max volume
            poc_idx = np.argmax(bin_volumes)
            poc = float(bin_centers[poc_idx])
            
            # Calculate Value Area (70% of total volume around POC)
            total_volume = float(np.sum(bin_volumes))
            if total_volume <= 0:
                return self._empty_profile("Zero total volume")
            
            target_volume = total_volume * self.value_area_pct
            
            # Expand from POC outward until we capture 70% of volume
            vah_idx, val_idx = self._find_value_area(bin_volumes, poc_idx, target_volume)
            vah = float(bin_centers[vah_idx])
            val = float(bin_centers[val_idx])
            
            # Identify High Volume Nodes (HVN) - local maxima above 80th percentile
            hvn_levels = self._find_volume_nodes(bin_centers, bin_volumes, threshold_pct=0.80)
            
            # Identify Low Volume Nodes (LVN) - local minima below 20th percentile
            lvn_levels = self._find_volume_nodes(bin_centers, bin_volumes, threshold_pct=0.20, find_minima=True)
            
            # Create volume distribution dict
            volume_distribution = {float(bin_centers[i]): float(bin_volumes[i]) 
                                  for i in range(len(bin_centers))}
            
            # Build result
            result = VolumeProfileResult(
                poc=poc,
                vah=vah,
                val=val,
                hvn_levels=hvn_levels,
                lvn_levels=lvn_levels,
                volume_distribution=volume_distribution,
                total_volume=total_volume,
                valid=True
            )
            
            # Cache result
            with self._cache_lock:
                self._cache = result
                self._cache_key = cache_key
            
            logger.debug(f"[VOLUME_PROFILE] Calculated: {result}")
            return result
            
        except Exception as e:
            logger.error(f"[VOLUME_PROFILE] Calculation failed: {e}")
            return self._empty_profile(f"Error: {e}")
    
    def _find_value_area(self, bin_volumes: np.ndarray, poc_idx: int, 
                        target_volume: float) -> Tuple[int, int]:
        """
        Find Value Area High/Low indices by expanding from POC.
        
        Args:
            bin_volumes: Volume for each bin
            poc_idx: Index of POC bin
            target_volume: Target cumulative volume (70% of total)
        
        Returns:
            (vah_idx, val_idx) tuple
        """
        num_bins = len(bin_volumes)
        upper_idx = poc_idx
        lower_idx = poc_idx
        cumulative_volume = bin_volumes[poc_idx]
        
        # Expand outward from POC until we capture target volume
        while cumulative_volume < target_volume:
            # Check which direction has more volume
            upper_vol = bin_volumes[upper_idx + 1] if upper_idx < num_bins - 1 else 0
            lower_vol = bin_volumes[lower_idx - 1] if lower_idx > 0 else 0
            
            if upper_vol == 0 and lower_vol == 0:
                break  # No more volume to capture
            
            # Expand in direction of higher volume
            if upper_vol >= lower_vol and upper_idx < num_bins - 1:
                upper_idx += 1
                cumulative_volume += bin_volumes[upper_idx]
            elif lower_idx > 0:
                lower_idx -= 1
                cumulative_volume += bin_volumes[lower_idx]
            else:
                break
        
        return upper_idx, lower_idx
    
    def _find_volume_nodes(self, bin_centers: np.ndarray, bin_volumes: np.ndarray, 
                          threshold_pct: float = 0.80, find_minima: bool = False) -> List[float]:
        """
        Find High Volume Nodes (local maxima) or Low Volume Nodes (local minima).
        
        Args:
            bin_centers: Price levels for each bin
            bin_volumes: Volume for each bin
            threshold_pct: Percentile threshold (0.80 = 80th percentile)
            find_minima: If True, find LVN (minima), else HVN (maxima)
        
        Returns:
            List of price levels representing volume nodes
        """
        if len(bin_volumes) < 3:
            return []
        
        # Calculate threshold
        threshold = float(np.percentile(bin_volumes, threshold_pct * 100))
        
        nodes = []
        for i in range(1, len(bin_volumes) - 1):
            is_local_extrema = False
            
            if find_minima:
                # Local minimum (LVN)
                if (bin_volumes[i] < bin_volumes[i-1] and 
                    bin_volumes[i] < bin_volumes[i+1] and
                    bin_volumes[i] < threshold):
                    is_local_extrema = True
            else:
                # Local maximum (HVN)
                if (bin_volumes[i] > bin_volumes[i-1] and 
                    bin_volumes[i] > bin_volumes[i+1] and
                    bin_volumes[i] > threshold):
                    is_local_extrema = True
            
            if is_local_extrema:
                nodes.append(float(bin_centers[i]))
        
        return nodes
    
    def _empty_profile(self, reason: str) -> VolumeProfileResult:
        """Return an invalid/empty profile with safe defaults."""
        logger.debug(f"[VOLUME_PROFILE] Empty profile: {reason}")
        return VolumeProfileResult(
            poc=0.0,
            vah=0.0,
            val=0.0,
            hvn_levels=[],
            lvn_levels=[],
            volume_distribution={},
            total_volume=0.0,
            valid=False
        )
    
    def clear_cache(self):
        """Clear cached profile (useful for testing or forced recalculation)."""
        with self._cache_lock:
            self._cache = None
            self._cache_key = None


def get_nearest_level(price: float, levels: List[float], max_distance: float = None) -> Optional[float]:
    """
    Find the nearest volume level to a given price.
    
    Args:
        price: Current price
        levels: List of price levels (e.g., HVN or LVN)
        max_distance: Maximum distance to consider (optional)
    
    Returns:
        Nearest level or None if no levels within max_distance
    """
    if not levels:
        return None
    
    distances = [abs(price - level) for level in levels]
    min_distance = min(distances)
    
    if max_distance is not None and min_distance > max_distance:
        return None
    
    nearest_idx = distances.index(min_distance)
    return levels[nearest_idx]


def is_near_level(price: float, level: float, tolerance_pips: float) -> bool:
    """
    Check if price is near a specific level.
    
    Args:
        price: Current price
        level: Target level
        tolerance_pips: Tolerance in pips (use ATR-based value)
    
    Returns:
        True if price is within tolerance of level
    """
    return abs(price - level) <= tolerance_pips
