"""
Enhanced AI Training Pipeline for 1-5 Candle Directional Prediction

This module provides comprehensive training for the AETHER Oracle to accurately
predict market direction for the next 1, 2, 3, 4, and 5 candles.

Focus: Directional accuracy (UP/DOWN/NEUTRAL) rather than precise price targets.
"""

import os
import sys
import time
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import defaultdict

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset
except ImportError:
    print("ERROR: PyTorch not installed. Run: pip install torch")
    sys.exit(1)

try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
except ImportError:
    MT5_AVAILABLE = False
    print("WARNING: MetaTrader5 not available. Will use synthetic data only.")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("MultiHorizonTrainer")


@dataclass
class TrainingMetrics:
    """Training performance metrics."""
    epoch: int
    loss: float
    accuracy_1_candle: float
    accuracy_2_candle: float
    accuracy_3_candle: float
    accuracy_4_candle: float
    accuracy_5_candle: float
    avg_accuracy: float


class MultiHorizonModel(nn.Module):
    """
    Enhanced model for predicting next 1-5 candle directions.
    
    Architecture:
    - LSTM layers for temporal pattern recognition
    - Multi-head output for 5 separate predictions (1-5 candles ahead)
    - Each head predicts: DOWN (0), NEUTRAL (1), UP (2)
    """
    
    def __init__(self, input_dim=5, hidden_dim=128, num_layers=2, dropout=0.2):
        super(MultiHorizonModel, self).__init__()
        
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        
        # LSTM backbone
        self.lstm = nn.LSTM(
            input_dim, 
            hidden_dim, 
            num_layers, 
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )
        
        # 5 prediction heads (one for each candle ahead)
        self.head_1 = nn.Linear(hidden_dim, 3)  # Next 1 candle
        self.head_2 = nn.Linear(hidden_dim, 3)  # Next 2 candles
        self.head_3 = nn.Linear(hidden_dim, 3)  # Next 3 candles
        self.head_4 = nn.Linear(hidden_dim, 3)  # Next 4 candles
        self.head_5 = nn.Linear(hidden_dim, 3)  # Next 5 candles
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x):
        """
        Args:
            x: (batch, seq_len, input_dim)
            
        Returns:
            tuple of 5 tensors, each (batch, 3) for predictions 1-5 candles ahead
        """
        # LSTM forward
        lstm_out, _ = self.lstm(x)
        
        # Use last timestep
        last_hidden = lstm_out[:, -1, :]  # (batch, hidden_dim)
        last_hidden = self.dropout(last_hidden)
        
        # Predict each horizon
        pred_1 = self.head_1(last_hidden)
        pred_2 = self.head_2(last_hidden)
        pred_3 = self.head_3(last_hidden)
        pred_4 = self.head_4(last_hidden)
        pred_5 = self.head_5(last_hidden)
        
        return pred_1, pred_2, pred_3, pred_4, pred_5


class MultiHorizonTrainer:
    """
    Trains the enhanced multi-horizon predictor for 1-5 candle directional accuracy.
    """
    
    def __init__(
        self, 
        symbol="XAUUSD",
        timeframe="M1",
        model_path="models/multi_horizon_lstm.pth",
        data_cache_path="data/training_cache.npy"
    ):
        self.symbol = symbol
        self.timeframe = timeframe
        self.model_path = model_path
        self.data_cache_path = data_cache_path
        
        # Hyperparameters
        self.seq_len = 60  # Use last 60 candles to predict next 1-5
        self.batch_size = 64
        self.learning_rate = 0.001
        self.hidden_dim = 128
        self.num_layers = 2
        self.dropout = 0.3
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        logger.info(f"Using device: {self.device}")
        
        # Model
        self.model = None
        
        # Scaling
        self.price_scale = 1.0  # Will be set from data
        self.volume_scale = 1.0
        
    def fetch_mt5_data(self, num_candles=10000) -> Optional[pd.DataFrame]:
        """
        Fetch historical M1 candles from MT5.
        
        Args:
            num_candles: Number of candles to fetch
            
        Returns:
            DataFrame with OHLCV data or None if failed
        """
        if not MT5_AVAILABLE:
            logger.warning("MT5 not available. Use generate_synthetic_data() instead.")
            return None
        
        try:
            if not mt5.initialize():
                logger.error("MT5 initialization failed")
                return None
            
            # Get symbol info
            symbol_info = mt5.symbol_info(self.symbol)
            if symbol_info is None:
                logger.error(f"Symbol {self.symbol} not found")
                mt5.shutdown()
                return None
            
            # Enable symbol
            if not symbol_info.visible:
                if not mt5.symbol_select(self.symbol, True):
                    logger.error(f"Failed to select {self.symbol}")
                    mt5.shutdown()
                    return None
            
            # Fetch candles
            logger.info(f"Fetching {num_candles} {self.timeframe} candles for {self.symbol}...")
            
            # Map timeframe
            tf_map = {
                "M1": mt5.TIMEFRAME_M1,
                "M5": mt5.TIMEFRAME_M5,
                "M15": mt5.TIMEFRAME_M15,
                "H1": mt5.TIMEFRAME_H1,
            }
            
            timeframe_mt5 = tf_map.get(self.timeframe, mt5.TIMEFRAME_M1)
            
            rates = mt5.copy_rates_from_pos(self.symbol, timeframe_mt5, 0, num_candles)
            
            mt5.shutdown()
            
            if rates is None or len(rates) == 0:
                logger.error("No data received from MT5")
                return None
            
            # Convert to DataFrame
            df = pd.DataFrame(rates)
            df['time'] = pd.to_datetime(df['time'], unit='s')
            
            logger.info(f"Fetched {len(df)} candles from {df['time'].min()} to {df['time'].max()}")
            
            return df[['time', 'open', 'high', 'low', 'close', 'tick_volume']]
            
        except Exception as e:
            logger.error(f"Error fetching MT5 data: {e}")
            if MT5_AVAILABLE:
                mt5.shutdown()
            return None
    
    def generate_synthetic_data(self, num_candles=10000) -> pd.DataFrame:
        """
        Generate synthetic OHLCV data for training when MT5 is unavailable.
        
        Args:
            num_candles: Number of candles to generate
            
        Returns:
            DataFrame with synthetic OHLCV data
        """
        logger.info(f"Generating {num_candles} synthetic candles...")
        
        # Generate realistic price movement using random walk with drift and volatility
        np.random.seed(42)
        
        base_price = 2500.0
        prices = [base_price]
        volumes = []
        
        for i in range(num_candles):
            # Random walk with mean reversion
            drift = 0.0001 * np.random.randn()
            volatility = 0.5
            change = drift + volatility * np.random.randn()
            
            # Add trending behavior
            if i % 100 < 40:  # 40% of time trending up
                change += 0.3
            elif i % 100 < 80:  # 40% of time trending down
                change -= 0.3
            # else: 20% ranging
            
            new_price = prices[-1] + change
            prices.append(new_price)
            
            # Random volume
            volumes.append(np.random.randint(100, 1000))
        
        prices = np.array(prices)
        
        # Create OHLC from prices
        data = []
        for i in range(1, len(prices)):
            open_price = prices[i-1]
            close_price = prices[i]
            
            # High and low based on volatility
            spread = abs(close_price - open_price) * np.random.uniform(1.2, 2.0)
            high_price = max(open_price, close_price) + spread * 0.5
            low_price = min(open_price, close_price) - spread * 0.5
            
            data.append({
                'time': pd.Timestamp('2024-01-01') + pd.Timedelta(minutes=i),
                'open': open_price,
                'high': high_price,
                'low': low_price,
                'close': close_price,
                'tick_volume': volumes[i-1]
            })
        
        df = pd.DataFrame(data)
        logger.info(f"Generated {len(df)} synthetic candles")
        
        return df
    
    def prepare_training_data(
        self, 
        df: pd.DataFrame
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Convert OHLCV data to sequences with multi-horizon labels.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            (X, y1, y2, y3, y4, y5) where:
            - X: Input sequences (batch, seq_len, 5)
            - y1-y5: Labels for 1-5 candles ahead (batch,)
        """
        logger.info("Preparing training sequences...")
        
        # Extract OHLCV
        ohlcv = df[['open', 'high', 'low', 'close', 'tick_volume']].values
        
        # Normalize
        self.price_scale = np.median(ohlcv[:, :4])  # Use median of OHLC
        self.volume_scale = np.median(ohlcv[:, 4]) if np.median(ohlcv[:, 4]) > 0 else 1.0
        
        ohlcv_norm = ohlcv.copy().astype(float)
        ohlcv_norm[:, :4] /= self.price_scale  # Normalize prices
        ohlcv_norm[:, 4] /= self.volume_scale  # Normalize volume
        
        # Create sequences
        sequences = []
        labels_1 = []
        labels_2 = []
        labels_3 = []
        labels_4 = []
        labels_5 = []
        
        for i in range(len(ohlcv_norm) - self.seq_len - 5):
            # Input: last seq_len candles
            seq = ohlcv_norm[i:i + self.seq_len]
            sequences.append(seq)
            
            # Current close (reference price)
            current_close = ohlcv[i + self.seq_len - 1, 3]
            
            # Labels: direction for next 1-5 candles
            for horizon, labels_list in enumerate([labels_1, labels_2, labels_3, labels_4, labels_5], start=1):
                future_close = ohlcv[i + self.seq_len + horizon - 1, 3]
                diff = future_close - current_close
                
                # Classify: DOWN (0), NEUTRAL (1), UP (2)
                # Threshold: 0.02% of price (for Gold ~$0.50)
                threshold = current_close * 0.0002
                
                if diff > threshold:
                    label = 2  # UP
                elif diff < -threshold:
                    label = 0  # DOWN
                else:
                    label = 1  # NEUTRAL
                
                labels_list.append(label)
        
        X = np.array(sequences, dtype=np.float32)
        y1 = np.array(labels_1, dtype=np.int64)
        y2 = np.array(labels_2, dtype=np.int64)
        y3 = np.array(labels_3, dtype=np.int64)
        y4 = np.array(labels_4, dtype=np.int64)
        y5 = np.array(labels_5, dtype=np.int64)
        
        logger.info(f"Created {len(X)} training sequences")
        logger.info(f"Input shape: {X.shape}")
        logger.info(f"Label distribution (1-candle): UP={np.sum(y1==2)}, DOWN={np.sum(y1==0)}, NEUTRAL={np.sum(y1==1)}")
        
        return X, y1, y2, y3, y4, y5
    
    def train(
        self, 
        epochs=20, 
        validation_split=0.2,
        use_mt5_data=True,
        num_candles=10000
    ) -> List[TrainingMetrics]:
        """
        Train the multi-horizon model.
        
        Args:
            epochs: Number of training epochs
            validation_split: Fraction of data for validation
            use_mt5_data: If True, try to fetch MT5 data first
            num_candles: Number of candles to fetch/generate
            
        Returns:
            List of TrainingMetrics for each epoch
        """
        logger.info("=" * 80)
        logger.info("STARTING MULTI-HORIZON TRAINING")
        logger.info("=" * 80)
        
        # Step 1: Get data
        if use_mt5_data and MT5_AVAILABLE:
            df = self.fetch_mt5_data(num_candles)
            if df is None:
                logger.warning("MT5 fetch failed. Using synthetic data.")
                df = self.generate_synthetic_data(num_candles)
        else:
            df = self.generate_synthetic_data(num_candles)
        
        # Step 2: Prepare sequences
        X, y1, y2, y3, y4, y5 = self.prepare_training_data(df)
        
        # Step 3: Train/val split
        split_idx = int(len(X) * (1 - validation_split))
        
        X_train, X_val = X[:split_idx], X[split_idx:]
        y1_train, y1_val = y1[:split_idx], y1[split_idx:]
        y2_train, y2_val = y2[:split_idx], y2[split_idx:]
        y3_train, y3_val = y3[:split_idx], y3[split_idx:]
        y4_train, y4_val = y4[:split_idx], y4[split_idx:]
        y5_train, y5_val = y5[:split_idx], y5[split_idx:]
        
        logger.info(f"Training samples: {len(X_train)}, Validation samples: {len(X_val)}")
        
        # Step 4: Create DataLoaders
        train_dataset = TensorDataset(
            torch.FloatTensor(X_train),
            torch.LongTensor(y1_train),
            torch.LongTensor(y2_train),
            torch.LongTensor(y3_train),
            torch.LongTensor(y4_train),
            torch.LongTensor(y5_train)
        )
        
        val_dataset = TensorDataset(
            torch.FloatTensor(X_val),
            torch.LongTensor(y1_val),
            torch.LongTensor(y2_val),
            torch.LongTensor(y3_val),
            torch.LongTensor(y4_val),
            torch.LongTensor(y5_val)
        )
        
        train_loader = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=self.batch_size, shuffle=False)
        
        # Step 5: Initialize model
        self.model = MultiHorizonModel(
            input_dim=5,
            hidden_dim=self.hidden_dim,
            num_layers=self.num_layers,
            dropout=self.dropout
        ).to(self.device)
        
        logger.info(f"Model parameters: {sum(p.numel() for p in self.model.parameters()):,}")
        
        # Step 6: Loss and optimizer
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=3, factor=0.5)
        
        # Step 7: Training loop
        metrics_history = []
        best_val_loss = float('inf')
        
        for epoch in range(epochs):
            # Training
            self.model.train()
            train_loss = 0.0
            train_steps = 0
            
            for batch_X, batch_y1, batch_y2, batch_y3, batch_y4, batch_y5 in train_loader:
                batch_X = batch_X.to(self.device)
                batch_y1 = batch_y1.to(self.device)
                batch_y2 = batch_y2.to(self.device)
                batch_y3 = batch_y3.to(self.device)
                batch_y4 = batch_y4.to(self.device)
                batch_y5 = batch_y5.to(self.device)
                
                optimizer.zero_grad()
                
                # Forward
                pred1, pred2, pred3, pred4, pred5 = self.model(batch_X)
                
                # Loss for each horizon
                loss1 = criterion(pred1, batch_y1)
                loss2 = criterion(pred2, batch_y2)
                loss3 = criterion(pred3, batch_y3)
                loss4 = criterion(pred4, batch_y4)
                loss5 = criterion(pred5, batch_y5)
                
                # Total loss (weighted: more weight on closer predictions)
                loss = (loss1 * 0.3 + loss2 * 0.25 + loss3 * 0.2 + loss4 * 0.15 + loss5 * 0.1)
                
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                optimizer.step()
                
                train_loss += loss.item()
                train_steps += 1
            
            avg_train_loss = train_loss / train_steps
            
            # Validation
            self.model.eval()
            val_loss = 0.0
            val_steps = 0
            
            correct_1, correct_2, correct_3, correct_4, correct_5 = 0, 0, 0, 0, 0
            total = 0
            
            with torch.no_grad():
                for batch_X, batch_y1, batch_y2, batch_y3, batch_y4, batch_y5 in val_loader:
                    batch_X = batch_X.to(self.device)
                    batch_y1 = batch_y1.to(self.device)
                    batch_y2 = batch_y2.to(self.device)
                    batch_y3 = batch_y3.to(self.device)
                    batch_y4 = batch_y4.to(self.device)
                    batch_y5 = batch_y5.to(self.device)
                    
                    pred1, pred2, pred3, pred4, pred5 = self.model(batch_X)
                    
                    loss1 = criterion(pred1, batch_y1)
                    loss2 = criterion(pred2, batch_y2)
                    loss3 = criterion(pred3, batch_y3)
                    loss4 = criterion(pred4, batch_y4)
                    loss5 = criterion(pred5, batch_y5)
                    
                    loss = (loss1 * 0.3 + loss2 * 0.25 + loss3 * 0.2 + loss4 * 0.15 + loss5 * 0.1)
                    
                    val_loss += loss.item()
                    val_steps += 1
                    
                    # Accuracy
                    _, predicted_1 = torch.max(pred1, 1)
                    _, predicted_2 = torch.max(pred2, 1)
                    _, predicted_3 = torch.max(pred3, 1)
                    _, predicted_4 = torch.max(pred4, 1)
                    _, predicted_5 = torch.max(pred5, 1)
                    
                    correct_1 += (predicted_1 == batch_y1).sum().item()
                    correct_2 += (predicted_2 == batch_y2).sum().item()
                    correct_3 += (predicted_3 == batch_y3).sum().item()
                    correct_4 += (predicted_4 == batch_y4).sum().item()
                    correct_5 += (predicted_5 == batch_y5).sum().item()
                    
                    total += batch_y1.size(0)
            
            avg_val_loss = val_loss / val_steps
            
            acc_1 = correct_1 / total
            acc_2 = correct_2 / total
            acc_3 = correct_3 / total
            acc_4 = correct_4 / total
            acc_5 = correct_5 / total
            avg_acc = (acc_1 + acc_2 + acc_3 + acc_4 + acc_5) / 5
            
            # Save metrics
            metrics = TrainingMetrics(
                epoch=epoch + 1,
                loss=avg_val_loss,
                accuracy_1_candle=acc_1,
                accuracy_2_candle=acc_2,
                accuracy_3_candle=acc_3,
                accuracy_4_candle=acc_4,
                accuracy_5_candle=acc_5,
                avg_accuracy=avg_acc
            )
            metrics_history.append(metrics)
            
            # Logging
            logger.info(f"Epoch {epoch+1}/{epochs} | "
                       f"Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f}")
            logger.info(f"  Accuracies: 1c={acc_1:.1%} | 2c={acc_2:.1%} | 3c={acc_3:.1%} | "
                       f"4c={acc_4:.1%} | 5c={acc_5:.1%} | Avg={avg_acc:.1%}")
            
            # Save best model
            if avg_val_loss < best_val_loss:
                best_val_loss = avg_val_loss
                self.save_model()
                logger.info(f"  ✅ New best model saved (val_loss: {best_val_loss:.4f})")
            
            # Learning rate scheduling
            scheduler.step(avg_val_loss)
        
        logger.info("=" * 80)
        logger.info("TRAINING COMPLETE")
        logger.info("=" * 80)
        
        return metrics_history
    
    def save_model(self):
        """Save model to disk."""
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
        
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'price_scale': self.price_scale,
            'volume_scale': self.volume_scale,
            'seq_len': self.seq_len,
            'hidden_dim': self.hidden_dim,
            'num_layers': self.num_layers
        }, self.model_path)
        
        logger.info(f"Model saved to {self.model_path}")
    
    def load_model(self):
        """Load model from disk."""
        if not os.path.exists(self.model_path):
            logger.warning(f"No model found at {self.model_path}")
            return False
        
        checkpoint = torch.load(self.model_path, map_location=self.device)
        
        self.model = MultiHorizonModel(
            input_dim=5,
            hidden_dim=checkpoint.get('hidden_dim', self.hidden_dim),
            num_layers=checkpoint.get('num_layers', self.num_layers),
            dropout=self.dropout
        ).to(self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.price_scale = checkpoint.get('price_scale', 1.0)
        self.volume_scale = checkpoint.get('volume_scale', 1.0)
        
        logger.info(f"Model loaded from {self.model_path}")
        return True


def main():
    """Main training function."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Train Multi-Horizon Directional Predictor")
    parser.add_argument('--epochs', type=int, default=20, help="Number of training epochs")
    parser.add_argument('--candles', type=int, default=10000, help="Number of candles to use")
    parser.add_argument('--use-mt5', action='store_true', help="Use MT5 data if available")
    parser.add_argument('--symbol', type=str, default="XAUUSD", help="Trading symbol")
    
    args = parser.parse_args()
    
    trainer = MultiHorizonTrainer(symbol=args.symbol)
    
    metrics = trainer.train(
        epochs=args.epochs,
        use_mt5_data=args.use_mt5,
        num_candles=args.candles
    )
    
    # Print final results
    final = metrics[-1]
    print("\n" + "=" * 80)
    print("FINAL RESULTS")
    print("=" * 80)
    print(f"1-Candle Accuracy: {final.accuracy_1_candle:.1%}")
    print(f"2-Candle Accuracy: {final.accuracy_2_candle:.1%}")
    print(f"3-Candle Accuracy: {final.accuracy_3_candle:.1%}")
    print(f"4-Candle Accuracy: {final.accuracy_4_candle:.1%}")
    print(f"5-Candle Accuracy: {final.accuracy_5_candle:.1%}")
    print(f"Average Accuracy:  {final.avg_accuracy:.1%}")
    print("=" * 80)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
